This is the Matlab code for Table S21.


The matlab codes:

main_simulation.m: This file is used to calculate the values of LSIR model for Case 1 with n=100, 500.

Case1.m: This file is the setting for Case 1.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m and Simulation_oracle.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

Simulation_oracle.m: This file includes specific calculation steps for oracle estimator.

myfilename.m: This file is used to determine the saving path for the calculation results.

result_TableS21.m: This file is used to obtain Table S21.


You can directly carry out the code: main_TableS21.m.