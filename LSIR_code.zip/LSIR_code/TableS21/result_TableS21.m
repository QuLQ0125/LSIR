
vecMn=[1,5,5];n=125;sigma_star=1;example=1;
vecpen={'Oracle','SCAD','MCP'};c1=1;nu=0.7;varphi_type='LSIR';
TableS21_n100=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    TableS21_n100=[TableS21_n100,Result(:,3:end)];
end
TableS21_n100(end-1,:)=[];

vecMn=[1,5,5];n=625;sigma_star=1;example=1;
vecpen={'Oracle','SCAD','MCP'};c1=1;nu=0.7;varphi_type='LSIR';
TableS21_n500=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    TableS21_n500=[TableS21_n500,Result(:,3:end)];
end
TableS21_n500(end-1,:)=[];

TableS21=[TableS21_n100;TableS21_n500];


alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['n100-alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['n100-tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['n100-beta',num2str(s3+1)];
end
for s4=1:d2
    gamma_cell{s4}=['n100-gamma',num2str(s4)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['n500-alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['n500-tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['n500-beta',num2str(s3+1)];
end
for s4=1:d2
    gamma_cell{s4}=['n500-gamma',num2str(s4)];
end

row_labels=[row_labels,alpha_cell,tau_cell,beta_cell,gamma_cell];
col_labels={'Oracle-Bias','Oracle-SE','Oracle-SD','Oracle-CP',...
    'SCAD-Bias','SCAD-SE','SCAD-SD','SACD-CP',...
    'MCP-Bias','MCP-SE','MCP-SD','MCP-CP'};
TableS21_tabletype = array2table(TableS21, ...
    'VariableNames',col_labels,'RowNames', row_labels)