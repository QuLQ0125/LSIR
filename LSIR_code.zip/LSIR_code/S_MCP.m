function eta=S_MCP(zeta,lambda,t,vartheta)
%%%---MCP---%%%
if t<=1/vartheta
    fprintf('t>1/vartheta?\n')
end


eta=(ST(zeta,lambda/vartheta,t,vartheta))./(1-1/(t*vartheta)).*(abs(zeta)<=t*lambda)+zeta.*(abs(zeta)>t*lambda);

