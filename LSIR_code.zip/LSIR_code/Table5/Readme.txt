This is the Matlab code for Table 5.


The matlab codes:

main_testing_Case4.m: This file is used to calculate the values of power for Case 4.

main_testing_Case5.m: This file is used to calculate the values of power for Case 5.

Case4.m: This file is the setting for Case 4.

Case5.m: This file is the setting for Case 5.

mygendate.m, gendata.m are used to generate simulated data.

Simulation_test.m: This file includes specific calculation steps for obtaining power.

myfilename.m: This file is used to determine the saving path for the calculation results.

result_Table5.m: This file is used to obtain Table 5.


You can directly carry out the code: main_Table5.m