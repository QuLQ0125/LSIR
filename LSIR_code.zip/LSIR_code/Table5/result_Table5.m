% n1=1000;
Mn=0;n=500;vecsigma_star=[1,22,41];example=4;c1=1;nu=0.678;varphi_type='LSIR';
result_Table5_Case4_n500=[];
for i_sigma=1:length(vecsigma_star)
    sigma_star=vecsigma_star(i_sigma);
    load(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))
    result_Table5_Case4_n500=[result_Table5_Case4_n500;Result];
    
end


Mn=0;n=1000;vecsigma_star=[1,22,41];example=4;c1=1;nu=0.678;varphi_type='LSIR';
result_Table5_Case4_n1000=[];
for i_sigma=1:length(vecsigma_star)
    sigma_star=vecsigma_star(i_sigma);
    load(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))
    result_Table5_Case4_n1000=[result_Table5_Case4_n1000;Result];
    
end



Mn=0;n=500;vecsigma_star=[1,22,41];example=5;c1=1;nu=0.678;varphi_type='LSIR';
result_Table5_Case5_n500=[];
for i_sigma=1:length(vecsigma_star)
    sigma_star=vecsigma_star(i_sigma);
    load(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))
    result_Table5_Case5_n500=[result_Table5_Case5_n500;Result];
    
end


Mn=0;n=1000;vecsigma_star=[1,22,41];example=5;c1=1;nu=0.678;varphi_type='LSIR';
result_Table5_Case5_n1000=[];
for i_sigma=1:length(vecsigma_star)
    sigma_star=vecsigma_star(i_sigma);
    load(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))
    result_Table5_Case5_n1000=[result_Table5_Case5_n1000;Result];
    
end

Table5=[[result_Table5_Case4_n500,result_Table5_Case4_n1000];[result_Table5_Case5_n500,result_Table5_Case5_n1000]]*100;

row_labels={'Case4-N(0,1)-nu0.6','Case4-N(0,1)-nu0.7','Case4-N(0,1)-nu0.8',...
            'Case4-SChi^2(2)-nu0.6','Case4-SChi^2(2)-nu0.7','Case4-SChi^2(2)-nu0.8',...
            'Case4-t(4)-nu0.6','Case4-t(4)-nu0.7','Case4-t(4)-nu0.8',...
            'Case5-N(0,1)-nu0.6','Case5-N(0,1)-nu0.7','Case5-N(0,1)-nu0.8',...
            'Case5-SChi^2(2)-nu0.6','Case5-SChi^2(2)-nu0.7','Case5-SChi^2(2)-nu0.8',...
            'Case5-t(4)-nu0.6','Case5-t(4)-nu0.7','Case5-t(4)-nu0.8'};
col_labels={'n500-tilde_alpha=0','n500-0.05','n500-0.1','n500-0.15','n500-0.2','n500-0.25',...
            'n1000-tilde_alpha=0','n1000-0.05','n1000-0.1','n1000-0.15','n1000-0.2','n1000-0.25'};
Table5_tabletype = array2table(Table5, ...
    'VariableNames',col_labels,'RowNames', row_labels)