clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

%%%---input---%%%
vec_tildeAlpha=[0:0.1:0.5];%tilde_alpha
vec_nu=[0.6,0.7,0.8];%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
n1=1000;%the replications times

n=500;%the sample size
sigma_star=1;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)

Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
        
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))
save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))


n=1000;%the sample size


Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
        
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))

save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))







n=500;%the sample size
sigma_star=22;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)

Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
        
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))
save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))


n=1000;%the sample size


Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
        
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))
save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))








n=500;%the sample size
sigma_star=41;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)

Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
       
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))
 save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))


n=1000;%the sample size


Result=[];
for k1=1:length(vec_tildeAlpha)
    tilde_alpha=vec_tildeAlpha(:,k1);

    [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case4(tilde_alpha);%Case 4, Case 5
   
    [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

    for k2=1:length(vec_nu)
        nu=vec_nu(k2);
        c1=1;
        deltan=c1*(log(5+1)/n)^(nu);     
        Mn=0;    
        vectau0=linspace(-2.5,2.5,100);
        varpim=tilde_alpha*sqrt(n);
        power=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha);
        Result(k2,k1)=power;
        
    end
end
if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
%%%---output---%%%
disp(['Power analysis with ','epsilon_i~',distribution,', n=',num2str(n),', and nu=0.6 0.7 0.8 (column)']);
disp(array2table(Result,'VariableNames',{'tilde_alpha=0','0.1','0.2','0.3','0.4','0.5'}))
save(myfilename(Mn,n,n1,sigma_star,example,'Null',c1,0.678,varphi_type))