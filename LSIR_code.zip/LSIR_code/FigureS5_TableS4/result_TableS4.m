disp('SCAD')
load('fish_LSIR_est_SCAD_extremepoint.mat')
TableS4_SCAD=results_LSIR.resultTable

disp('MCP')
load('fish_LSIR_est_MCP_extremepoint.mat')
TableS4_MCP=results_LSIR.resultTable