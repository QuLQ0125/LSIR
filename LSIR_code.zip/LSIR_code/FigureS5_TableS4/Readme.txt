This is the Matlab code for Figure S5 and Table S4.

The matlab codes:

main_fish_LSIR_SCAD_extremepoint.m: This file is used to calculate the estimated values of the LSIR model on the  fish toxicity dataset  after removing a extreme data point , where the penalty function is SCAD.

main_fish_LSIR_MCP_extremepoint.m: This file is used to calculate the estimated values of the LSIR model on the  fish toxicity dataset  after removing a extreme data point, where the penalty function is MCP.

plot_figureS5.m: This file is used to draw Figure S5.

result_TableS4.m: This file is used to obtain Table S4.


You can directly carry out the code: main_FigureS5_TableS4.m.



