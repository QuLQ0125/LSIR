clc;clear;close all

main_fish_LSIR_SCAD_extremepoint

main_fish_LSIR_MCP_extremepoint

clc
plot_FigureS5

result_TableS4


