function objectiveTB=funTBZ(X,y,tildeZ,Alpha,Eta,deltan)
L=length(Alpha);
% n=size(X,1);
% funBeta=@(Beta) Alpha(1)*(X(:,1)+X(:,2)*Beta(1)+X(:,3)*Beta(2));
funTB=@(TB) Alpha(1)*(X(:,1)+X(:,2:end)*TB(L:end));%%funTau=@(Tau) Alpha(1)*(X*Beta);
for j=2:L
   funTBj=@(TB) Alpha(j)*qn(X(:,1)+X(:,2:end)*TB(L:end),TB(j-1),deltan);  
   funTB=@(TB) funTB(TB)+funTBj(TB);
end
% funTB=@(TB) sum(Alpha'.*[(X(:,1)+X(:,2:end)*TB(L:end)),qn(X(:,1)+X(:,2:end)*TB(L:end),TB(1:(L-1))',deltan)],2);
% funTB=@(TB) [(X(:,1)+X(:,2:end)*TB(L:end)),qn(X(:,1)+X(:,2:end)*TB(L:end),TB(1:(L-1))',deltan)]*Alpha;
y=@(TB) y;
z=@(TB) tildeZ*Eta;
%objectiveBeta=@(Beta) 1/2*norm(y(Beta)-funBeta(Beta)-z(Beta))^2;
objectiveTB=@(TB) 1/2*sum((y(TB)-funTB(TB)-z(TB)).^2);