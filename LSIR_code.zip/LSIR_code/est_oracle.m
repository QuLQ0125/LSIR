function [Eta1,Beta11,Alpha1,Tau1,BIC]=est_oracle(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,deltan,MI,tol)
%%%---oracle estimator---%%%
%Z,X,y is train data
%Mn is the given number of knots
%Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1 is initial values
%deltan is smoothness parameter
%MI is the maximum number of iterations
%tol tol is the tolerance parameter


opts1 = optimoptions('fmincon','MaxIterations',100,'StepTolerance',10^(-6),'Display','off','Algorithm', 'sqp');
opts2 = optimoptions('fmincon','MaxIterations',100,'StepTolerance',10^(-6),'Display','off','Algorithm', 'sqp');
n=size(X,1);
d1=size(X,2);
tildeZ=[ones(n,1),Z];
d2=size(Z,2);
cn=log(log(n));

Ip2=eye(Mn,Mn);
pairs = [1:Mn-1; 2:Mn]';  
A = Ip2(:, pairs(:,1))' - Ip2(:, pairs(:,2))';

Beta0=Beta0wan1;
Eta0=Eta0wan1;
Alpha0=Alpha0wan1;%zeros(Mn+1,1);
if isempty(Tau0wan1)
    Tau0=zeros(0,1);
else
    Tau0=Tau0wan1;
end
err=inf;e=1;
while err>tol && e<=MI
    
    Q0=[];
    T0=(X(:,1)+X(:,2:end)*Beta0);
    Q0=[T0,qn(T0,Tau0',deltan)];

    
    objectiveAlpha = @(Alpha) 1/2*norm(y-tildeZ*Eta0-Q0*Alpha)^2;
    Alpha1 = fmincon(objectiveAlpha,Alpha0,[],[],[],[],[],[],[],opts1);
    
    objectiveEta = @(Eta) 1/2*norm(y-tildeZ*Eta-Q0*Alpha1)^2;
    Eta1 = fmincon(objectiveEta,Eta0,[],[],[],[],[],[],[],opts2);
    
%         Alpha1=(Q0'*Q0)\(Q0'*(y-tildeZ*Eta0));
%         Eta1=(tildeZ'*tildeZ)\(tildeZ'*(y-Q0*Alpha1));
    
    
    
    objectiveTB=funTBZ(X,y,tildeZ,Alpha1,Eta1,deltan);
    rangeT=quantile(X(:,1)+X(:,2:end)*Beta0, 0.99)-quantile(X(:,1)+X(:,2:end)*Beta0, 0.01);
    TB1= fmincon(objectiveTB,[Tau0;Beta0],[A,zeros(Mn-1,length(Beta0))],-rangeT/30*ones(Mn-1,1),[],[],...
        [ones(Mn,1)*quantile(X(:,1)+X(:,2:end)*Beta0, 0.01);-ones(length(Beta0),1)*10],...
        [ones(Mn,1)*quantile(X(:,1)+X(:,2:end)*Beta0, 0.99);ones(length(Beta0),1)*10],[],opts1);
    Tau1=TB1(1:Mn,:);Beta1=TB1((Mn+1):end,:);
    
    
    
   
    err=norm([Alpha1;Beta1;Tau1;Eta1]-[Alpha0;Beta0;Tau0;Eta0]);
   
    
    Alpha0=Alpha1;
    Tau0=Tau1;
    Beta0=Beta1;
    Eta0=Eta1;
    e=e+1;
end

Beta11=[1;Beta1];
ess=sum((y-tildeZ*Eta1-Q0*Alpha1).^2);
hatMn=sum(abs(Alpha1(2:end))~=0);
BIC=[log(ess/n)+cn*log(n)/(n*2)*(2*hatMn+2+d1+d2),e];

%  hatvarphi=@(w) Eta1(1)+[w,f0(w,Tau1')]*Alpha1;plot(X*[1;Beta1],y-Z*Eta1(2:end),'.',sort(X*[1;Beta1]),hatvarphi(sort(X*[1;Beta1])),'-','Linewidth',2)
%  hatvarphi=@(w) Eta1(1)+w*Alpha1;plot(X*[1;Beta1],y-Z*Eta1(2:end),'.',sort(X*[1;Beta1]),hatvarphi(sort(X*[1;Beta1])),'-','Linewidth',2)
