function [beta_hat,gamma_hat,hatf_fun,coefficients_hat]=est_PR_global(X,Z,y,degree,beta0,gamma0)
% MATLAB script for local quasi-likelihood estimation in a generalized single index model

X1=X(:,1);
X2=X(:,2:end);
n=size(X,1);


[hatbeta0,hatgamma0,hatf_fun0,hatcoefficients0]=est_PR(X,Z,y,degree,beta0,gamma0);

bhatbeta=[];bhatgamma=[];bloss=[];bhatf_fun={};bcoefficients=[];
B=5;
    for b=1:B
        ransampleindex=randsample([1:n],n,true)';
        X_randsample=X(ransampleindex,:);
        Z_randsample=Z(ransampleindex,:);
        y_randsample=y(ransampleindex,:);
        [tilde_star_beta1,tilde_star_gamma1,tilde_star_f_fun1,tilde_star_coefficients]=est_PR(X_randsample,Z_randsample,y_randsample,degree,2*rand(size(X2,2),1)-1,hatgamma0);%
        
        [tilde_beta1,tilde_gamma1,tilde_f_fun1,tilde_coefficients]=est_PR(X,Z,y,degree,tilde_star_beta1,tilde_star_gamma1);
        
        loss_tilde_Theta=sum((y-tilde_f_fun1(X*[1;tilde_beta1])-Z*tilde_gamma1).^2);
        loss_hat_Theta0=sum((y-hatf_fun0(X*[1;hatbeta0])-Z*hatgamma0).^2);
        if loss_tilde_Theta<loss_hat_Theta0
            bhatbeta(:,b)=tilde_beta1;
            bhatf_fun{b}=tilde_f_fun1;
            bhatgamma(:,b)= tilde_gamma1;
            bcoefficients(b,:)=tilde_coefficients;
        else
            bhatbeta(:,b)=hatbeta0;
            bhatf_fun{b}=hatf_fun0;
            bhatgamma(:,b)= hatgamma0;
            bcoefficients(b,:)=hatcoefficients0;
        end
        hatf_fun_b= bhatf_fun{b};
        bloss(b,:)=sum((y-hatf_fun_b(X*[1;bhatbeta(:,b)])-Z*bhatgamma(:,b)).^2);
        
        %next b
        hatbeta0=bhatbeta(:,b);
        hatgamma0= bhatgamma(:,b);
        hatf_fun0=bhatf_fun{b};
        hatcoefficients0=bcoefficients(b,:);
    end

    loss_hatTheta_min=min(bloss);
    ste_bepsilon_index=abs((bloss-loss_hatTheta_min)./loss_hatTheta_min)<=1e-4;
    set_b=[1:B]';
    ste_bepsilon=set_b(ste_bepsilon_index);
    %     B_epsilon=sum(ste_bepsilon_index);
    
    
    beta_hat=mean(bhatbeta(:,ste_bepsilon),2);
    gamma_hat=mean(bhatgamma(:,ste_bepsilon),2);
    coefficients_hat=mean(bcoefficients(ste_bepsilon,:),1);
    hatf_fun=@(x) polyval(coefficients_hat, x);
    u=linspace(min(X1+X2 * beta_hat),max(X1+X2 * beta_hat),50);
%     plot(u,hatf_fun(u),'.')
    
end