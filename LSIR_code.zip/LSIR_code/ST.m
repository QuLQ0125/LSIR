function st=ST(zeta,lambda,~,~)
%%%----ST----%%%
st=(zeta+lambda).*(zeta<(-lambda))+(zeta-lambda).*(zeta>lambda)+0.*(abs(zeta)<=lambda);


