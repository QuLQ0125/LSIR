data=[];
vecMn=[10,15,15];n=1250;sigma_star=0.5;example=1;
vecpen={'Oracle','SCAD','MCP'};c1=1;nu=0.7;varphi_type='LSIR';
TableS2=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    TableS2=[TableS2,Result(:,3:end)];
end
TableS2(end-1,:)=[];

alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:d2
    gamma_cell{s4}=['gamma',num2str(s4)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
col_labels={'Oracle-Bias','Oracle-SE','Oracle-SD','Oracle-CP',...
    'SCAD-Bias','SCAD-SE','SCAD-SD','SACD-CP',...
    'MCP-Bias','MCP-SE','MCP-SD','MCP-CP'};
TableS2_tabletype = array2table(TableS2, ...
    'VariableNames',col_labels,'RowNames', row_labels)
