This is the Matlab code for Table S22.


The matlab codes:

main_taipei_LSIR_SCAD_group_1_10.m: This file is used to calculate the values of R^2 for all groups on the real estate valuation  dataset, where the penalty function is SCAD.

main_taipei_LSIR_MCP_group_1_10.m: This file is used to calculate the values of R^2 for all groups on the real estate valuation  dataset, where the penalty function is MCP.

result_TableS22.m: This file is used to obtain Table S22.


You can directly carry out the code: main_TableS22.m.
