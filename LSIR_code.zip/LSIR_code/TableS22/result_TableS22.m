TableS22=[];
for groupdouble=1:10
    load(['group',num2str(groupdouble),'-taipei_LSIR_est_SCAD.mat'])
    TableS22(groupdouble,1)=results_LSIR.R2;
end

for groupdouble=1:10
    load(['group',num2str(groupdouble),'-taipei_LSIR_est_MCP.mat'])
    TableS22(groupdouble,2)=results_LSIR.R2;
end


row_labels={'Group1','Group2','Group3','Group4','Group5','Group6','Group7','Group8','Group9','Group10'};
col_labels={'R^2 (SCAD)','R^2 (MCP)'};
TableS22_tabletype = array2table(TableS22, ...
    'VariableNames',col_labels,'RowNames', row_labels)