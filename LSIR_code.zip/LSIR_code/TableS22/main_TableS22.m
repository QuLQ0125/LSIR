clc;clear;close all
main_taipei_LSIR_SCAD_group1_10

main_taipei_LSIR_MCP_group1_10

clc
result_TableS22