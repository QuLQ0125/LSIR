This is the Matlab code for Figure 1.

You can directly carry out the code: main_Figure1.m.