clc;clear
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);
deltan= 1;
tau=0;
x = -3:0.1:3;

y=0.*(x<=tau)+(x-tau).*(x>tau);
y1=0.*(x<tau-deltan)+(x-tau+deltan).^2/(4*deltan).*(x>=tau-deltan & x<=tau+deltan) +(x-tau).*(x>tau+deltan);
y2=deltan.*log(1+exp((x-tau)./deltan));
y3=(x-tau).*normcdf((x-tau)/deltan) + deltan .* normpdf((x-tau)/deltan);
y4=(-(x-tau).^4/deltan^3+6*(x-tau).^2/deltan+8*(x-tau)+3*deltan)/16.*(abs(x-tau)<=deltan)+(x-tau).*((x-tau)>deltan); 


figure('Position', [200, 200, 800,600]);
plot(x,y,'-','Color',[21 29 41]/255,'linewidth',3.6,'DisplayName','$f(x,\tau)$')
hold on;plot(x,y4,'--','DisplayName','Epanechnikov kernel','Color',[107 121 142]/255,'linewidth',3.5)
hold on;plot(x,y1,'-.','DisplayName','Uniform kernel','Color',[108 168 175]/255,'linewidth',3.5)

hold on;plot(x,y3,':','DisplayName','Gaussian kernel','Color',[166 186 177]/255,'linewidth',3.5);
hold on;plot(x,y2,'-','DisplayName','Logistic kernel','Color',[236 235 194]/255,'linewidth',3.5)


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$x$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$q_n(x)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
xticks([-3:3])
yticks([-3:3])
xlim([-3,3])
ylim([0,3])
set(legend,'interpreter','latex','Fontsize',22,'Fontname','Times New Roman','Location','NorthWest',...
    'LineWidth',0.75)
legend()




deltan= 0.5;
y5=0.*(x<tau-deltan)+(x-tau+deltan).^2/(4*deltan).*(x>=tau-deltan & x<=tau+deltan) +(x-tau).*(x>tau+deltan);
deltan= 1;
y6=0.*(x<tau-deltan)+(x-tau+deltan).^2/(4*deltan).*(x>=tau-deltan & x<=tau+deltan) +(x-tau).*(x>tau+deltan);
deltan= 1.5;
y7=0.*(x<tau-deltan)+(x-tau+deltan).^2/(4*deltan).*(x>=tau-deltan & x<=tau+deltan) +(x-tau).*(x>tau+deltan);
deltan= 2;
y8=0.*(x<tau-deltan)+(x-tau+deltan).^2/(4*deltan).*(x>=tau-deltan & x<=tau+deltan) +(x-tau).*(x>tau+deltan);


figure('Position', [200, 200, 800,600]);
plot(x,y,'-','Color',[21 29 41]/255,'linewidth',3.6,'DisplayName','$f(x,\tau)$')
hold on;plot(x,y5,'--','DisplayName','$\delta_n=0.5$','Color',[107 121 142]/255,'linewidth',3.5)
hold on;plot(x,y6,'-.','DisplayName','$\delta_n=1.0$','Color',[108 168 175]/255,'linewidth',3.5)

hold on;plot(x,y7,':','DisplayName','$\delta_n=1.5$','Color',[166 186 177]/255,'linewidth',3.5);
hold on;plot(x,y8,'-','DisplayName','$\delta_n=2.0$','Color',[236 235 194]/255,'linewidth',3.5)


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$x$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$q_n(x)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
xticks([-3:3])
yticks([-3:3])
xlim([-3,3])
ylim([0,3])
set(legend,'interpreter','latex','Fontsize',22,'Fontname','Times New Roman','Location','NorthWest',...
    'LineWidth',0.75)
legend()