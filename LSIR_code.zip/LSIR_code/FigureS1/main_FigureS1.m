clc;clear;close all
main_simulation

clc
plot_FigureS1