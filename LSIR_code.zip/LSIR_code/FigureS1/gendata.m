function [Z,X,y,Epsilon,T]=gendata(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,varphi)
ZX=mvnrnd([meanZ,meanX],eye(d2+d1)*0.5+ones(d2+d1)*0.5,n);
Z=ZX(:,1:d2);
X(:,1)=ZX(:,d2+1);
if length(Tau_star)==1
    X(:,2:d1)=7*normcdf(ZX(:,d2+2:end))-3.5;%ZX(:,iotaZ+2:end);%
elseif length(Tau_star)==2
    X(:,2:d1)=7*normcdf(ZX(:,d2+2:end))-3.5;
elseif length(Tau_star)==4
    X(:,2:d1)=7*normcdf(ZX(:,d2+2:end))-3.5;
else
    X(:,2:d1)=7*normcdf(ZX(:,d2+2:end))-3.5;
end
T=X*Beta_star;
Q_star=[];
if isempty(Tau_star)
    Q_star=T;
else
    Q_star=[T,f0(T,Tau_star')];
end

if sigma_star<=1  
    Epsilon=normrnd(0,sigma_star,n,1);
elseif sigma_star==41
    Epsilon=trnd(floor(sigma_star/10),n,1);
elseif sigma_star==22
    Epsilon=(chi2rnd(2,n,1)-2)/2;
end
  

y=Z*Eta_star(2:end)+varphi(T)+Epsilon;
% figure;plot(T,y-Z*Eta_star(2:end),'.');figure;plot(T,varphi(T),'.')