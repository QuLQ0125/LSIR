figure('Position', [200, 200, 800,600]);
% n1=100;

vecMn=[5:15];vectime_SCAD=[];
n=1250;sigma_star=1;example=1;pen='SCAD';c1=1;nu=0.7;varphi_type='LSIR';
for i_Mn=1:length(vecMn)
    Mn=vecMn(i_Mn);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    vectime_SCAD(i_Mn)=mean(reruntime)/B;
end

vecMn=[5:15];vectime_MCP=[];
n=1250;sigma_star=1;example=1;pen='MCP';c1=1;nu=0.7;varphi_type='LSIR';
for i_Mn=1:length(vecMn)
    Mn=vecMn(i_Mn);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    vectime_MCP(i_Mn)=mean(reruntime)/B;
end


plot(vecMn,vectime_SCAD,'-','LineWidth',3,'Marker','o','Markersize',8,'Color',[0.00,0.45,0.74]);
hold on;plot(vecMn,vectime_MCP,'-','LineWidth',3,'Marker','.','Markersize',30,'Color',[0.85,0.33,0.10]);
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
legend('SCAD','MCP','Location','NorthWest','Fontname','Times New Roman','FontSize',24);
xlabel('$M_n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('Computation time (seconds)','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
desired_xticks =[5:2:15];
xticks(desired_xticks )