This is the Matlab code for Figure S1.


The matlab codes:

main_simulation.m: This file is used to calculate the average computation times (seconds) for Mn=5 to 15.

Case1.m: This file is the setting for Case 1.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

est_ADMM_time.m: This function is used to calculate the computation times (seconds) according to ADMM algorithm.

Global_ADMM_time.m: This function is used to calculate the average computation times (seconds) according to the bootstrap adjustment method.

myfilename.m: This file is used to determine the saving path for the calculation results.

plot_FigureS1.m: This file is used to draw Figure S1.



You can directly carry out the code: main_FigureS1.m.