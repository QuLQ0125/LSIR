disp('Table 7-SCAD')
load('fish_LSIR_est_SCAD.mat')
Table7_SCAD=results_LSIR.resultTable

disp('fish 7-MCP')
load('fish_LSIR_est_MCP.mat')
Table7_MCP=results_LSIR.resultTable