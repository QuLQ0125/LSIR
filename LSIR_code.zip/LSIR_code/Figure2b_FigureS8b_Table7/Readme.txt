This is the Matlab code for Figure 2b, Table 7 and Figure S8b.

The matlab codes:

main_fish_LR.m: This file is used to calculate the estimated values of the LR model on the fish toxicity dataset.

main_fish_PLSIR.m: This file is used to calculate the estimated values of the PLSIR model on the  fish toxicity dataset.

main_fish_LSIR_SCAD.m: This file is used to calculate the estimated values of the LSIR model on the  fish toxicity dataset, where the penalty function is SCAD.

main_fish_LSIR_MCP.m: This file is used to calculate the estimated values of the LSIR model on the  fish toxicity dataset, where the penalty function is MCP.

plot_figure2b.m: This file is used to draw Figure 2b.

result_Table7.m: This file is used to obtain Table 7.

plot_figureS8b.m: This file is used to draw Figure S8b.


You can directly carry out the code: main_Figure2b_Table7_FigureS8b.m.



