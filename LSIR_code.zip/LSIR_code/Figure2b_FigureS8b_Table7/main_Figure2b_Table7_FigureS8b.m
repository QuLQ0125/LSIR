clc;clear;close all

main_fish_LSIR_SCAD

main_fish_LSIR_MCP

main_fish_PLSIR

main_fish_LR

clc
plot_Figure2b

plot_FigureS8b

result_Table7