clc;clear;close all
%%%---fish_LR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];%removing a extreme data point
variable_names={'CIC0','SM1\_Dz(Z)',' GATS1i','NdsCH','NdssC','MLOGP '};
example=4;
XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


X_train=X;Z_train=Z;y_train=y;

    
XZ_train=[X_train,ones(size(X_train,1),1),Z_train];
bg=(XZ_train'*XZ_train)\(XZ_train'*y_train);

RMSE_LR_train=sqrt(mean((y_train-XZ_train*bg).^2));
ESS_LR_train=sum((y_train-XZ_train*bg).^2);
TSS_LR_train=sum((y_train-mean(y_train)).^2);
R2_LR_train=1-ESS_LR_train/TSS_LR_train;


hatGamma1=bg(size(X_train,2)+2:end);
hatBeta1wan=bg(1:size(X_train,2));
hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
hatalpha0=hatBeta1wan(1);
hatgamma0=bg(size(X_train,2)+1);


disp('Linear regression model (LR)')
disp(['group: variables LC50 as y, ','variables ',strjoin(variable_names(SCXI),', '),' as X and ','variables ',strjoin(variable_names(SDXI),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',R2_LR_train],'VariableNames',col_labels);
disp(PEtable)

save('fish_LR_est.mat')


