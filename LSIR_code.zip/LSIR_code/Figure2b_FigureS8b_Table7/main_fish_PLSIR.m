clc;clear;close all
%%%---fish_PLSIR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];%removing a extreme data point
variable_names={'CIC0','SM1\_Dz(Z)',' GATS1i','NdsCH','NdssC','MLOGP '};

XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];
X_train=X;Z_train=Z;y_train=y;

h=0.9;

[beta_hat,gamma_hat]=est_PR_global(X_train,Z_train,y_train,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
tic
[hatBeta1,hatGamma1]=est_SIR_wang(X_train,Z_train,y_train,beta_hat,gamma_hat,h);
runtime=toc;
Ynew=y_train-Z_train*hatGamma1;
Xnew=X_train*[1;hatBeta1];
x=sort(Xnew);
hatYnew=hatf_fun_wang(Xnew,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
hatynew=hatf_fun_wang(x,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
RMSE_SIR_train=sqrt(mean((y_train-Z_train*hatGamma1-hatYnew).^2));
ESS_train=sum((y_train-hatYnew-Z_train*hatGamma1).^2);
TSS_train=sum((y_train-mean(y_train)).^2);
R2_train=1-ESS_train/TSS_train;


disp('Partially linear single index regression model (PLSIR)')
disp(['group: variables LC50 as y, ','variables ',strjoin(variable_names(SCXI),', '),' as X and ','variables ',strjoin(variable_names(SDXI),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',R2_train],'VariableNames',col_labels);
disp(PEtable)

save('fish_PLSIR_est.mat')