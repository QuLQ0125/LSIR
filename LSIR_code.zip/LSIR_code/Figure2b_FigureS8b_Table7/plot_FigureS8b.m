clc;clear;
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];
XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
d1=size(X,2);
d2=size(Z,2);
tildeZ=[ones(n,1),Z];

load('fish_LSIR_est_SCAD.mat')
hatBeta11=results_LSIR.hatbeta;
hatEta1=results_LSIR.hateta;
hatTau1=results_LSIR.hattau;
hatAlpha1=results_LSIR.hatalpha;
LhatTau1=results_LSIR.CI([(length(hatAlpha1)+1):(length(hatAlpha1)+length(hatTau1))],1);
UhatTau1=results_LSIR.CI([(length(hatAlpha1)+1):(length(hatAlpha1)+length(hatTau1))],2);

figure('Position', [200, 200, 800,600]);

hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
haty_LSIR=Z*hatEta1(2:end)+hatvarphi(X*hatBeta11);
hat_Epsilon_LSIR=y-haty_LSIR;
plot([1,8],[0,0],'k-','LineWidth',1.5)
hold on;
plot(haty_LSIR,hat_Epsilon_LSIR,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
title('(b) Fish toxicity dataset','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:1:100];
desired_yticks =[-6:3:6];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([1,8])
ylim([-6,6])