function [hatSE,hatsigma2,hatXI,hatV2]=est_SE(y,Z,X,hatEta,hatBeta,hatAlpha,hatTau,hatlambda,deltan,hatt,pen)
%%%---SE: estimate of variance--%%%
%%%---penalty function---%%%
Funcollect=EvalutionFunc;
if strcmp(pen,'MCP')
    fun0=Funcollect.myMCP;
    fun=@S_MCP;
    dfun=Funcollect.mydMCP;
    d2fun=Funcollect.myd2MCP;
elseif strcmp(pen,'SCAD')
    fun0=Funcollect.mySCAD;
    fun=@S_SCAD;
    dfun=Funcollect.mydSCAD;
    d2fun=Funcollect.myd2SCAD;
elseif strcmp(pen,'Lasso')
    fun0=Funcollect.myST;
    fun=@ST;
    dfun=Funcollect.mydST;
    d2fun=Funcollect.myd2ST;
end


n=size(X,1);
Q0=[];
T0=X*hatBeta;
Q0=[T0,qn(T0,hatTau',deltan)];
tildeZ=[ones(n,1),Z];
try
    hatEpsilon=y-tildeZ*hatEta-Q0*hatAlpha;
catch
    fprintf('error：');
    hatAlpha
    hatTau
    hatBeta
    hatGamma
end
hatsigma2=1/n*sum(hatEpsilon.^2);
s1=length(hatAlpha);
s2=length(hatTau);
s3=length(hatBeta)-1;
s4=length(hatEta);
s=s1+s2+s3+s4;
HH=zeros(s,s);
HHn=zeros(s,s);
for i=1:n
    tildeZi=tildeZ(i,:)';
    H5i=tildeZi';
    Xi=X(i,:)';
    X2i=X(i,2:end)';
    H1i=Xi'*hatBeta;
    H4i=hatAlpha(1)*X2i';
    Hn4i=hatAlpha(1)*X2i';
    H2i=[];Hn2i=[];
    H3i=[];Hn3i=[];
    for j=1:length(hatTau)
    H4i=H4i+hatAlpha(j+1)*X2i'*1*(Xi'*hatBeta>hatTau(j));
    H2i=[H2i,(Xi'*hatBeta-hatTau(j))*1*(Xi'*hatBeta>hatTau(j))];
    H3i=[H3i,hatAlpha(j+1)*(-1)*(Xi'*hatBeta>hatTau(j))];
    
    Hn4i=Hn4i+hatAlpha(j+1)*X2i'*1*(Xi'*hatBeta>hatTau(j)+deltan)+...
            hatAlpha(j+1)*(Xi'*hatBeta-hatTau(j)+deltan)/(2*deltan)*X2i'*1*(Xi'*hatBeta>=hatTau(j)-deltan & Xi'*hatBeta<=hatTau(j)+deltan);
    Hn2i=[Hn2i,qn(Xi'*hatBeta,hatTau(j),deltan)];
    Hn3i=[Hn3i,hatAlpha(j+1)*(-1)*(Xi'*hatBeta>hatTau(j)+deltan)+...
            hatAlpha(j+1)*(Xi'*hatBeta-hatTau(j)+deltan)/(2*deltan)*(-1)*(Xi'*hatBeta>=hatTau(j)-deltan & Xi'*hatBeta<=hatTau(j)+deltan)];%这里是-1
    end
    Hi=[H1i,H2i,H3i,H4i,H5i]';
    mHH=Hi*Hi';
    HH=HH+mHH;
    Hni=[H1i,Hn2i,Hn3i,Hn4i,H5i]';
    mHHn=Hni*Hni';
    HHn=HHn+mHHn;
end
hatV=1/n*HH;

hatV1=hatsigma2*hatV;

hatV2=1/n*HHn;
hatV3=hatsigma2*hatV2;

SL1=[];
b1=[];
for j=1:length(hatTau)
    SL1=[SL1,d2fun(hatAlpha(j+1),hatt,hatlambda)];
    b1=[b1,dfun(hatAlpha(j+1),hatt,hatlambda)];
end
SL=diag([0,SL1,zeros(1,s2+s3+s4)]);
b=[0,b1,zeros(1,s2+s3+s4)]';
dotU=hatV2+SL;
hatXI=1/n*(dotU\hatV3)/dotU;
hatSE=sqrt(diag(hatXI));

