data=[];
vecMn=[5,7,10];n=1250;sigma_star=1;example=1;
pen='SCAD';c1=1;nu=0.7;varphi_type='LSIR';
result_TableS1_SCAD=[];
for j_Mn=1:length(vecMn)
    Mn=vecMn(j_Mn);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    result_TableS1_SCAD=[result_TableS1_SCAD,Result(:,3:end)];
end
result_TableS1_SCAD(end-1,:)=[];

vecMn=[5,7,10];n=1250;sigma_star=1;example=1;
pen='MCP';c1=1;nu=0.7;varphi_type='LSIR';
result_TableS1_MCP=[];
for j_Mn=1:length(vecMn)
    Mn=vecMn(j_Mn);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    result_TableS1_MCP=[result_TableS1_MCP,Result(:,3:end)];
end
result_TableS1_MCP(end-1,:)=[];



TableS1=[result_TableS1_SCAD;result_TableS1_MCP];


alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['SCAD-alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['SCAD-tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['SCAD-beta',num2str(s3+1)];
end
for s4=1:d2
    gamma_cell{s4}=['SCAD-gamma',num2str(s4)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['MCP-alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['MCP-tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['MCP-beta',num2str(s3+1)];
end
for s4=1:d2
    gamma_cell{s4}=['MCP-gamma',num2str(s4)];
end

row_labels=[row_labels,alpha_cell,tau_cell,beta_cell,gamma_cell];
col_labels={'Mn=5-Bias','Mn=5-SE','Mn=5-SD','Mn=5-CP',...
    'Mn=7-Bias','Mn=7-SE','Mn=7-SD','Mn=7-CP',...
    'Mn=10-Bias','Mn=10-SE','Mn=10-SD','Mn=10-CP'};
TableS1_tabletype = array2table(TableS1, ...
    'VariableNames',col_labels,'RowNames', row_labels)