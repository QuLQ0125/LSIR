This is the Matlab code for Table S1.


The matlab codes:

main_simulation.m: This file is used to calculate the values of LSIR model for Case 1 with Mn=5, 7, 10.

Case1.m: This file is the setting for Case 1.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

myfilename.m: This file is used to determine the saving path for the calculation results.

result_TableS1.m: This file is used to obtain Table S1.


You can directly carry out the code: main_TableS1.m.