This is the Matlab code for Table S24.


The matlab codes:

main_fish_LSIR_SCAD_group_1_10.m: This file is used to calculate the values of R^2 for all groups on the fish toxicity dataset, where the penalty function is SCAD.

main_fish_LSIR_MCP_group_1_10.m: This file is used to calculate the values of R^2 for all groups on the fish toxicity dataset, where the penalty function is MCP.

result_TableS24.m: This file is used to obtain Table S24.


You can directly carry out the code: main_TableS24.m.
