TableS24=[];
for groupdouble=1:11
    load(['Group',num2str(groupdouble),'-fish_LSIR_est_SCAD.mat'])
    TableS24(groupdouble,1)=results_LSIR.R2;
end

for groupdouble=1:11
    load(['Group',num2str(groupdouble),'-fish_LSIR_est_MCP.mat'])
    TableS24(groupdouble,2)=results_LSIR.R2;
end


row_labels={'Group1','Group2','Group3','Group4','Group5','Group6','Group7','Group8','Group9','Group10','Group11'};
col_labels={'R^2 (SCAD)','R^2 (MCP)'};
TableS24_tabletype = array2table(TableS24, ...
    'VariableNames',col_labels,'RowNames', row_labels)