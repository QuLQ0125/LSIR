function [pvalue,T,T1_star_alpha,T1,T1_star,psi,hatEpsi,hatvar_rho]=test_knots(y,Z,X,hatEta,hatBeta,hatAlpha,hatTau,deltan,vectau0,varpim,Tau_star)
n=size(X,1);
Q0=[];
T0=X*hatBeta;
tildeZ=[ones(n,1),Z];
varpimTau=Tau_star;
if isempty(varpimTau)
    Q0=T0;
else
    Q0=[T0,qn(T0,varpimTau',deltan)];
end

try
    hatEpsilon=y-tildeZ*hatEta-Q0*[hatAlpha;varpim/sqrt(n)];
    
catch
    fprintf('error');
    hatAlpha
    hatTau
    hatBeta
    hatEta
end
hatsigma2=1/n*sum(hatEpsilon.^2);
s1=length(hatAlpha);
s2=length(hatTau);
s3=length(hatBeta)-1;
s4=length(hatEta);
s=s1+s2+s3+s4;
HH=zeros(s,s);
HHn=zeros(s,s);
for i=1:n
    tildeZi=tildeZ(i,:)';
    H5i=tildeZi';
    Xi=X(i,:)';
    X2i=X(i,2:end)';
    H1i=Xi'*hatBeta;
    H4i=hatAlpha(1)*X2i';
    Hn4i=hatAlpha(1)*X2i';
    H2i=[];Hn2i=[];
    H3i=[];Hn3i=[];
    for j=1:length(hatTau)
        H4i=H4i+hatAlpha(j+1)*X2i'*1*(Xi'*hatBeta>hatTau(j));
        H2i=[H2i,(Xi'*hatBeta-hatTau(j))*1*(Xi'*hatBeta>hatTau(j))];
        H3i=[H3i,hatAlpha(j+1)*(-1)*(Xi'*hatBeta>hatTau(j))];
        
        Hn4i=Hn4i+hatAlpha(j+1)*X2i'*1*(Xi'*hatBeta>hatTau(j)+deltan)+...
            hatAlpha(j+1)*(Xi'*hatBeta-hatTau(j)+deltan)/(2*deltan)*X2i'*1*(Xi'*hatBeta>=hatTau(j)-deltan & Xi'*hatBeta<=hatTau(j)+deltan);
        Hn2i=[Hn2i,qn(Xi'*hatBeta,hatTau(j),deltan)];
        Hn3i=[Hn3i,hatAlpha(j+1)*(-1)*(Xi'*hatBeta>hatTau(j)+deltan)+...
            hatAlpha(j+1)*(Xi'*hatBeta-hatTau(j)+deltan)/(2*deltan)*(-1)*(Xi'*hatBeta>=hatTau(j)-deltan & Xi'*hatBeta<=hatTau(j)+deltan)];%这里是-1
    end
    Hi=[H1i,H2i,H3i,H4i,H5i]';
    mHH=Hi*Hi';
    HH=HH+mHH;
    Hni=[H1i,Hn2i,Hn3i,Hn4i,H5i]';
    mHHn=Hni*Hni';
    HHn=HHn+mHHn;
end
hatV=1/n*HH;

hatV1=hatsigma2*hatV;

hatV2=1/n*HHn;

hatV3=hatsigma2*hatV2;


xi=[X*hatBeta,hatAlpha(1)*X(:,2:end),tildeZ]';
D=xi*(f0(X*hatBeta,vectau0))/n;

hatEpsilon1=y-tildeZ*hatEta-T0*hatAlpha(1);
psi=(sum(qn(X*hatBeta,vectau0,deltan).*hatEpsilon1)/sqrt(n))';
hatEpsi=(f0(X*hatBeta,vectau0)-...
    [D'/hatV2*xi]')'*(f0(X*hatBeta,varpimTau')*varpim)/n;


gi=(xi'.*hatEpsilon1)';%xi(Y-Z^\top\Gamma-\alpha_0X^\top\beta)
psi_star=f0(X*hatBeta,vectau0).*hatEpsilon1-(D'/hatV2*gi)';
hatvar_rho=(mean(psi_star.^2))';
T1=psi.^2./hatvar_rho;
T=max(T1);

tildeG=normrnd(0,1,n,10000);%tildeG(:,1)=tildeG_i;
numerator=(tildeG'*psi_star/sqrt(n))';
T1_star=(max(numerator.^2./hatvar_rho))';

T1_star_alpha=quantile(T1_star,0.95);


XgeqT=(T1_star>T);
pvalue=mean(XgeqT);
