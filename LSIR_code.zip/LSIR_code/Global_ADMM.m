function [ansBIC,hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,hatAlpha111,hatTau111,BICmin]=Global_ADMM(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambda,t,deltan,cn,pen,maxiter,tol,B)
%%%---ADMM algorithm global---%%%
% Z,X,y: The train data.
% Mn: The number of knots to be selected.
% Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1: The initial values.
% Lambdawan: Some tuning parameter.
% t: A parameter that controls the concavity of the penalty function.
% deltan. The smoothness parameter.
% cn:  A predetermined constant in BIC.
% pen: A type of penalty function, i.e. 'SCAD' and 'MCP' .
% maxiter: The maximum number of iterations.
% tol:  The tolerance parameter.
% B: The bootstrape times.
% ifplot: Whether to draw or not, i.e. 'true', 'flase'.

D=10000;%a large number

Ip2=eye(Mn,Mn);
pairs = [1:Mn-1; 2:Mn]';  
A = Ip2(:, pairs(:,1))' - Ip2(:, pairs(:,2))';


%%%---penalty function---%%%
Funcollect=EvalutionFunc;
if strcmp(pen,'MCP')
    fun0=Funcollect.myMCP;
    fun=@S_MCP;
    dfun=Funcollect.mydMCP;
    d2fun=Funcollect.myd2MCP;
elseif strcmp(pen,'SCAD')
    fun0=Funcollect.mySCAD;
    fun=@S_SCAD;
    dfun=Funcollect.mydSCAD;
    d2fun=Funcollect.myd2SCAD;
elseif strcmp(pen,'Lasso')
    fun0=Funcollect.myST;
    fun=@ST;
    dfun=Funcollect.mydST;
    d2fun=Funcollect.myd2ST;
end

n=size(X,1);
d1=size(X,2);
tildeZ=[ones(n,1),Z];
d2=size(Z,2);


ansBIC=[];
% Alpha0wan1=zeros(Mn+1,1);

for L=1:length(Lambda)
    [hatAlpha0,hatTauwan0,hatBeta0,hatEta0,e]=est_ADMM(Z,X,y,Mn,D,A,Alpha0wan1,Beta0wan1,Eta0wan1,Tau0wan1,Lambda(L),t,deltan,fun,maxiter,tol);
    bhatAlpha=[];bhatBeta=[];bhatEta=[];bhatTauwan=[];bloss=[];
    for b=1:B
        ransampleindex=randsample([1:n],n,true)';
        X_randsample=X(ransampleindex,:);
        Z_randsample=Z(ransampleindex,:);
        y_randsample=y(ransampleindex,:);
        
        [breve_Alpha1,breve_Tauwan1,breve_Beta1,breve_Eta1,e]=est_ADMM(Z_randsample,X_randsample,y_randsample,Mn,D,A,hatAlpha0,hatBeta0,hatEta0,hatTauwan0,Lambda(L),t,deltan,fun,maxiter,tol);
        
        [tilde_Alpha1,tilde_Tauwan1,tilde_Beta1,tilde_Eta1,e]=est_ADMM(Z,X,y,Mn,D,A,breve_Alpha1,breve_Beta1,breve_Eta1,breve_Tauwan1,Lambda(L),t,deltan,fun,maxiter,tol);
        
        loss_tilde_Theta=1/2*sum((y-[X*[1;tilde_Beta1],f0(X*[1;tilde_Beta1],tilde_Tauwan1')]*tilde_Alpha1-tildeZ*tilde_Eta1).^2)+...
                            n*sum(fun0(tilde_Alpha1(2:end),t,Lambda(L)));
        loss_hat_Theta0=1/2*sum((y-[X*[1;hatBeta0],f0(X*[1;hatBeta0],hatTauwan0')]*hatAlpha0-tildeZ*hatEta0).^2)+...
                            n*sum(fun0(hatAlpha0(2:end),t,Lambda(L)));
        if loss_tilde_Theta<loss_hat_Theta0
            bhatBeta(:,b)=tilde_Beta1;
            bhatAlpha(:,b)=tilde_Alpha1;
            bhatEta(:,b)= tilde_Eta1;
            bhatTauwan(:,b)=tilde_Tauwan1;
        else
            bhatBeta(:,b)=hatBeta0;
            bhatAlpha(:,b)=hatAlpha0;
            bhatEta(:,b)= hatEta0;
            bhatTauwan(:,b)=hatTauwan0;
        end
        bloss(b,:)=1/2*sum((y-[X*[1;bhatBeta(:,b)],f0(X*[1;bhatBeta(:,b)],bhatTauwan(:,b)')]*bhatAlpha(:,b)-tildeZ*bhatEta(:,b)).^2)+...
                            n*sum(fun0(bhatAlpha(2:end,b),t,Lambda(L)));
        
        hatBeta0=bhatBeta(:,b);
        hatAlpha0=bhatAlpha(:,b);
        hatEta0= bhatEta(:,b);
        hatTauwan0=bhatTauwan(:,b);
 
    end
    
    loss_hatTheta_min=min(bloss);
    ste_bepsilon_index=abs((bloss-loss_hatTheta_min)./loss_hatTheta_min)<=1e-6;
    set_b=[1:B]';
    ste_bepsilon=set_b(ste_bepsilon_index);

    Beta1=mean(bhatBeta(:,ste_bepsilon),2);
    Alpha1=mean(bhatAlpha(:,ste_bepsilon),2);
    Zeta1=Alpha1(2:end);
    Eta1=mean(bhatEta(:,ste_bepsilon),2);
    Tauwan1=mean(bhatTauwan(:,ste_bepsilon),2);
    Tau1=[];
    Tau1=Tauwan1;%D.*(abs(Zeta1)<=1*10^(-4))+Tauwan1.*(abs(Zeta1)>1*10^(-4));
    V1=zeros(Mn,1);
    Beta11=[1;Beta1];
    Q0=[X*Beta11,f0(X*Beta11,Tau1')];
    ess=sum((y-tildeZ*Eta1-Q0*Alpha1).^2);
    hatMn=sum(abs(Alpha1(2:end))>0);
    BIC=log(ess/n)+cn*log(n)/(n*2)*(2*hatMn+2+d1+d2);
    
    for k=1:length(cn)
        ansBIC(L,:,k)=[Lambda(L),hatMn,BIC(k),e,Alpha1',Tau1',Beta11',Eta1',[0;V1]',[Alpha1(1);Zeta1]'];
    end
    
%     Alpha0wan1=Alpha1;
%     Tau0wan1=Tau1;
%     Beta0wan1=Beta1;
%     Eta0wan1=Eta1;
end
%  hatvarphi=@(w) Eta1(1)+[w,f0(w,Tau1')]*Alpha1;plot(X*[1;Beta1],y-Z*Eta1(2:end),'.',sort(X*[1;Beta1]),hatvarphi(sort(X*[1;Beta1])),'-','Linewidth',2)


[hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,hatAlpha111,hatTau111,BICmin]=choseBIC(ansBIC(:,:,1),Mn,d1,d2);