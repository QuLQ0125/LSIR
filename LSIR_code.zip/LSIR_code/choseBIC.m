function [hatEta1,hatBeta11,hatAlpha11,hatTau11,hatlambda,hatAlpha111,...
    hatTau111,BICmin]=choseBIC(ansBIC,Mn,d1,d2)
%%%---selecting lambda---%%%
[~,h]=min(ansBIC(:,3));
% BICmin=ansBIC(h,[1:4,end]);
% hatlambda=BICmin([1,5]);
BICmin=ansBIC(h,[1:4]);
hatlambda=BICmin(1);
hatAlpha1=ansBIC(h,5:5+Mn)';
hatTau1=ansBIC(h,(5+Mn+1):(5+Mn+Mn))';
hatAT=[hatAlpha1(2:end,:),hatTau1];
hatAT1=sortrows(hatAT,2);
hatAlpha111=[hatAlpha1(1,:);hatAT1(:,1)];
hatTau111=hatAT1(:,2);
% hatAlpha11=hatAlpha1(abs(hatAlpha1)>10^(-4));
% hatTau11=hatTau1(hatTau1~=D);
hatAlpha_n0=hatAlpha1(2:end);
tauindex=abs(hatAlpha_n0)>0;
hatAlpha11=[hatAlpha1(1);hatAlpha_n0(tauindex)];%hatAlpha1(abs(hatAlpha1)>10^(-4));
hatTau11=hatTau1(tauindex);%hatTau1(hatTau1~=D);

hatBeta11=ansBIC(h,(5+Mn+Mn+1):(5+Mn+Mn+d1))';

hatEta1=ansBIC(h,(5+Mn+Mn+d1+1):(5+Mn+Mn+d1+d2+1))';

