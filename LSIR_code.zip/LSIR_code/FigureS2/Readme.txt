This is the Matlab code for Figure S2.


The matlab codes:

main_simulation.m: This file is used to calculate the values of EE and PE for different methods and sample sizes n.

Case1.m: This file is the setting for Case 1.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m, Simulation_PLSIR.m and Simulation_LR.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

Simulation_PLSIR.m: This file includes specific calculation steps for PLSIR model.

Simulation_LR.m: This file includes specific calculation steps for LR model.

myfilename.m: This file is used to determine the saving path for the calculation results.

plot_FigureS2.m: This file is used to draw Figure S2.



You can directly carry out the code: main_FigureS2.m.