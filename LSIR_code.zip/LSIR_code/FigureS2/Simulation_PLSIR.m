function Simulation_PLSIR(pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type)
%%%---PLSIR---%%%
rehatTheta1=[];J=[];rehatEpsilon=[];cvRMSE=[];cvhatBeta1=[];cvhatGamma1=[];
reruntime=[];reRMSE_h=[];rehatfun={};reh=[];reRMSE=[];ref_hat=[];redf_hat=[];reu=[];

Beta0wan1=[];Eta0wan1=[];Tau0wan1=[];
Beta0wan1=Beta_star(2:end)-0.15*ones(size(Beta_star,1)-1,1);
Eta0wan1=Eta_star-0.1*ones(size(Eta_star,1),1);



iter=1;

while(iter<=n1)
    
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    
    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    n_train=size(X_train,1);
    X_test=X(ceil(train_rate*numSamples)+1:end,:);
    Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
    y_test=y(ceil(train_rate*numSamples)+1:end,:);
    n_test=size(X_test,1); 
    numSamples_train = size(X_train, 1);
    rng(124);
    indices_train = randperm(numSamples_train);
    X_train=X_train(indices_train,:);Z_train=Z_train(indices_train,:);y_train=y_train(indices_train,:);
    foldSize = floor(numSamples_train / 5);
    cvIndices = cell(5, 1);
    for i1 = 1:5
        startIdx = (i1 - 1) * foldSize + 1;
        endIdx = i1 * foldSize;
        if i1 == 5
            endIdx = numSamples_train;
        end
        cvIndices{i1} = startIdx:endIdx;
    end
    
    vech=[0.1:0.2:1];
    for k=1:length(vech)
        h=vech(k);
        for r=1:5
            testIdx_r = cvIndices{r};
            trainIdx_r = setdiff(1:numSamples_train, testIdx_r);
            X_train_r = X_train(trainIdx_r, :);
            Z_train_r = Z_train(trainIdx_r, :);
            y_train_r = y_train(trainIdx_r);
            X_test_r = X_train(testIdx_r, :);
            Z_test_r=Z_train(testIdx_r, :);
            y_test_r = y_train(testIdx_r);
            n_train_r=size(testIdx_r,1);
            [hatBeta1_r,hatGamma1_r]=est_SIR_wang(X_train_r,Z_train_r,y_train_r,Beta0wan1,Eta0wan1(2:end),h);
            ess=sqrt(mean((y_test_r-hatf_fun_wang(X_test_r*[1;hatBeta1_r],hatBeta1_r,hatGamma1_r,X_train_r,Z_train_r,y_train_r,h)-Z_test_r*hatGamma1_r).^2));
            %plot(X*[1;hatBeta1_r],y-Z*hatGamma1_r,'.',X*[1;hatBeta1_r],hatf_fun_wang(X*[1;hatBeta1_r],hatBeta1_r,hatGamma1_r,X_train_r,Z_train_r,y_train_r,h),'.')
            cvRMSE(r,:,k,iter)=[vech(k),ess];
            cvhatBeta1(:,r,k,iter)=hatBeta1_r;
            cvhatGamma1(:,r,k,iter)=hatGamma1_r;
        end
        
        reRMSE_h(k,:,iter)=mean(cvRMSE(:,:,k,iter));
        
    end
    

    [~,kopt]=min(reRMSE_h(:,2,iter));%selecting optimal h
    h=vech(kopt);
    reh(iter,:)=h;
    %all train set
    tic
    [hatBeta1,hatGamma1]=est_SIR_wang(X_train,Z_train,y_train,Beta0wan1,Eta0wan1(2:end),h);
    reruntime(iter,:)=toc;

    rehatEpsilon(:,iter)=y_train-hatf_fun_wang(X_train*[1;hatBeta1],hatBeta1,hatGamma1,X_train,Z_train,y_train,h)-Z_train*hatGamma1;
    rehatTheta1(iter,:)=[hatBeta1',hatGamma1'];
    J(iter,:)=[hatBeta1',hatGamma1']-[Beta_star(2:end)',Eta_star(2:end)'];
    
    RMSE_SIR_train=sqrt(mean((y_train-Z_train*hatGamma1-hatf_fun_wang(X_train*[1;hatBeta1],hatBeta1,hatGamma1,X_train,Z_train,y_train,h)).^2));
    RMSE_SIR_test=sqrt(mean((y_test-Z_test*hatGamma1-hatf_fun_wang(X_test*[1;hatBeta1],hatBeta1,hatGamma1,X_train,Z_train,y_train,h)).^2));
    
    ESS_SIR_train=sum((y_train-Z_train*hatGamma1-hatf_fun_wang(X_train*[1;hatBeta1],hatBeta1,hatGamma1,X_train,Z_train,y_train,h)).^2);
    TSS_SIR_train=sum((y_train-mean(y_train)).^2);
    R2_SIR_train=1-ESS_SIR_train/TSS_SIR_train;
    ESS_SIR_test=sum((y_test-Z_test*hatGamma1-hatf_fun_wang(X_test*[1;hatBeta1],hatBeta1,hatGamma1,X_train,Z_train,y_train,h)).^2);
    TSS_SIR_test=sum((y_test-mean(y_test)).^2);
    R2_SIR_test=1-ESS_SIR_test/TSS_SIR_test;
    
    reRMSE(iter,:)=[RMSE_SIR_train,RMSE_SIR_test,R2_SIR_train,R2_SIR_test];
    
    iter=iter+1;
end
mehatTheta1=mean(rehatTheta1,1);

Bias=mean(J);
SD=std(J);
SE=SD;
CP=mean(abs(J)./SE<=1.96);

EE=norm(Bias);
ans3=mean(reRMSE);
PE=ans3(:,2);


%%%---output---%%%
disp('Partially linear single index regression model (PLSIR)')
Result=[[Beta_star(2:end);Eta_star(2:end)'],mehatTheta1',Bias',SD'];

resultTable = array2table(Result, ...
    'VariableNames', {'Theta*','hatTheta','Bias','SD'});
disp(resultTable)
PEtable=array2table([norm(Bias),mean(reRMSE)],'VariableNames',{'||hatBeta-Beta*||+||hatGamma-Gamma*||','PE (train)','PE (test)*','R2 (train)','R2 (test)'});
disp(PEtable)

save(myfilename(0,n,n1,sigma_star,example,pen,1,0.7,varphi_type))
