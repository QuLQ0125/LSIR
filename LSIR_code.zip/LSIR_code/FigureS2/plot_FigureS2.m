%n1=2;
data=[];
vecMn=[3,7,10,3,7,10,0,0];vecn=[125,625,1250];sigma_star=1;example=1;
vecpen={'SCAD','SCAD','SCAD','MCP','MCP','MCP','PLSIR','LR'};c1=1;nu=0.7;varphi_type='LSIR';
vecn=[125,125,625,625,1250,1250];
for i_n=1:2:5
    for j_Mn=1:length(vecMn)
        n=vecn(i_n);
        Mn=vecMn(j_Mn);
        pen=vecpen{j_Mn};
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_n,j_Mn)=EE;
    end
end

vecMn=[3,7,10,3,7,10,0,0];vecn=[125,625,1250];sigma_star=1;example=1;
pen={'SCAD','SCAD','SCAD','MCP','MCP','MCP','PLSIR','LR'};c1=1;nu=0.7;varphi_type='LSIR';
vecn=[125,125,625,625,1250,1250];
for i_n=2:2:6
    for j_Mn=1:length(vecMn)
        n=vecn(i_n);
        Mn=vecMn(j_Mn);
        pen=vecpen{j_Mn};
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_n,j_Mn)=PE;
    end
end



figure
t = tiledlayout(2, 2, 'TileSpacing', 'loose', 'Padding', 'loose');
nexttile
bias_index=[1,3,5];
Mn3SCAD_bias=data(bias_index,1);
Mn7SCAD_bias=data(bias_index,2);
Mn10SCAD_bias=data(bias_index,3);
Mn3MCP_bias=data(bias_index,4);
Mn7MCP_bias=data(bias_index,5);
Mn10MCP_bias=data(bias_index,6);
LSIR_bias=data(bias_index,7);
LR_bias=data(bias_index,8);
n=[1,2,3];

PE_index=[2,4,6];
Mn3SCAD_PE=data(PE_index,1);
Mn7SCAD_PE=data(PE_index,2);
Mn10SCAD_PE=data(PE_index,3);
Mn3MCP_PE=data(PE_index,4);
Mn7MCP_PE=data(PE_index,5);
Mn10MCP_PE=data(PE_index,6);
LSIR_PE=data(PE_index,7);
LR_PE=data(PE_index,8);


plot(n,Mn3SCAD_bias,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_bias,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_bias,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(a) Estimation error with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
% desired_yticks =[0:0.1:0.4]*100;
% yticks(desired_yticks);
xticklabels({'100','500','1000'});

nexttile
plot(n,Mn3SCAD_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(b) PE with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
% desired_yticks =[1:0.1:1.3];
% yticks(desired_yticks);
% ylim([0.99,1.3])
xticklabels({'100','500','1000'});




nexttile
plot(n,Mn3MCP_bias,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_bias,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_bias,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(c) Estimation error with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
% desired_yticks =[0:0.1:0.4]*100;
% yticks(desired_yticks);
xticklabels({'100','500','1000'});

nexttile
plot(n,Mn3MCP_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(d) PE with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
% desired_yticks =[1:0.1:1.3];
% yticks(desired_yticks);
% ylim([0.99,1.3])
xticklabels({'100','500','1000'});



set(legend,'interpreter','latex','Fontsize',24,'Fontname','Times New Roman',...
    'LineWidth',0.75,'Orientation', 'horizontal')

lgd=legend();
lgd.Layout.Tile = 'south';



