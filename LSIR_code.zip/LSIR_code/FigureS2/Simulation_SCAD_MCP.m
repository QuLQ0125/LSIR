function Simulation_SCAD_MCP(Mn,Lambdawan,t,deltan,cn,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)
%%%---pen:SCAD and MCP---%%%
rehatsigma2=[];rehatV=[];
rehatlambda=[];rehatTheta1=[];rehatSE=[];J=[];reRMSE=[];reTau0wan1=[];
rehatMn_star=[];
rehatTheta111=[];
reansBIC=[];
reruntime=[];
rehatXI=[];

Ip2=eye(Mn,Mn);
A=[];
for i=1:(Mn-1)
    for j=(i+1)
        A=[A;(Ip2(:,i)-Ip2(:,j))'];
    end
end





Beta0wan1=[];Eta0wan1=[];Tau0wan1=[];
Beta0wan1=Beta_star(2:end)-0.1*ones(size(Beta_star,1)-1,1);
Eta0wan1=Eta_star-0.1*ones(size(Eta_star,1),1);


iter=1;i_cn1=0;i_cn2=0;i_cn3=0;
while(iter<=n1)
    iter
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);

    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    n_train=size(X_train,1);
    X_test=X(ceil(train_rate*numSamples)+1:end,:);
    Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
    y_test=y(ceil(train_rate*numSamples)+1:end,:);
    n_test=size(X_test,1);
    
    Tau0wan1=linspace(min(X_train*[1;Beta0wan1]),max(X_train*[1;Beta0wan1]),Mn+2)';
    Tau0wan1=Tau0wan1(2:end-1);
    reTau0wan1(:,iter)=Tau0wan1;
    tic
    [ansBIC]=Global_ADMM(Z_train,X_train,y_train,Mn,Beta0wan1,Eta0wan1,Tau0wan1,zeros(Mn+1,1),Lambdawan,t,deltan,cn,pen,1000,1e-4,B);
    reruntime(iter,:)=toc;
    reansBIC(:,:,:,iter)=ansBIC;
    for k=1:length(cn)
        [hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,hatAlpha111,hatTau111,BICmin]=choseBIC(ansBIC(:,:,k),Mn,size(X,2),size(Z,2));
        rehatMn_star(iter,:,k)=BICmin;
        rehatTheta111(iter,:,k)=[hatAlpha111',hatTau111',hatBeta11(2:end)',hatEta1'];
        if  BICmin(2)==Mn_star
            [hatSE,hatsigma2,hatXI,hatV]=est_SE(y_train,Z_train,X_train,hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,deltan,t,pen);
            rehatlambda(iter,k)=hatlambda;
            rehatTheta1(iter,:,k)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1'];
            J(iter,:,k)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1']-Theta_o_star;
            rehatXI(:,:,iter,k)=hatXI;
            rehatsigma2(iter,:,k)=hatsigma2;
            rehatV(:,:,iter,k)=hatV;
            rehatSE(iter,:,k)=hatSE';
            if k==1
                i_cn1=i_cn1+1;
            end
            if k==2
                i_cn2=i_cn2+1;
            end
            if k==3
                i_cn3=i_cn3+1;
            end
        else
            rehatlambda(iter,k)=0;
            rehatTheta1(iter,:,k)=zeros(1,sn_star);
            J(iter,:,k)=zeros(1,sn_star);
            rehatsigma2(iter,k)=0;
            rehatV(:,:,iter,k)=zeros(sn_star,sn_star);
            rehatSE(iter,:,k)=zeros(1,sn_star);
            rehatXI(:,:,iter)=zeros(sn_star,sn_star);
        end
        
        
        hatQ0_train=[];
        hatT0_train=X_train*hatBeta11;
        hatQ0_train=[hatT0_train,f0(hatT0_train,hatTau1')];
        RMSE_train=sqrt(mean((y_train-[ones(n_train,1),Z_train]*hatEta1-hatQ0_train*hatAlpha1).^2));
        ESS_train=sum((y_train-[ones(n_train,1),Z_train]*hatEta1-hatQ0_train*hatAlpha1).^2);
        TSS_train=sum((y_train-mean(y_train)).^2);
        R2_train=1-ESS_train/TSS_train;
        
        
        hatQ0_test=[];
        hatT0_test=X_test*hatBeta11;
        hatQ0_test=[hatT0_test,f0(hatT0_test,hatTau1')];
        RMSE_test=sqrt(mean((y_test-[ones(n_test,1),Z_test]*hatEta1-hatQ0_test*hatAlpha1).^2));
        ESS_test=sum((y_test-[ones(n_test,1),Z_test]*hatEta1-hatQ0_test*hatAlpha1).^2);
        TSS_test=sum((y_test-mean(y_test)).^2);
        R2_test=1-ESS_test/TSS_test;
        
        reRMSE(iter,:,k)=[RMSE_train,RMSE_test,R2_train,R2_test,BICmin(2)];
    end

    iter=iter+1;
   
end

i_cn=[i_cn1,i_cn2,i_cn3];

hatMn_starSD=[mean(rehatMn_star(:,2,:)),median(rehatMn_star(:,2,:)),std(rehatMn_star(:,2,:))];
PMn_star=[];mehatTheta1=[];Bias=[];SE=[];SD=[];CP=[];
for k=1:length(cn)
    pMn_star=tabulate(rehatMn_star(:,2,k));
    PMn_star(:,:,k)=[pMn_star;zeros(Mn+1-length(pMn_star(:,1)),3)];
    mehatTheta1(:,:,k)=sum(rehatTheta1(:,:,k))/i_cn(k);
    Bias(:,:,k)=sum(J(:,:,k))/i_cn(k);
    SE(:,:,k)=sum(rehatSE(:,:,k))/i_cn(k);
    J2=J(:,:,k);
    [a,~]=find(J2(:,1)~=0);
    J1=J2([a],:);
    if size(std(J1),2)==1
        SD(:,:,k)=zeros(1,size(J1,2));
        CP(:,:,k)=zeros(1,size(J1,2));
    else
        SD(:,:,k)=std(J1);
        CP(:,:,k)=mean(abs(J1)./SE(:,:,k)<=1.96);
    end
    
end


%%%---output---%%%
disp('penalized smoothing least squares eatimator')
vecCn={'Cn=1 in BIC','Cn=loglogn in BIC'};
k=1;
disp([{['Mn=',num2str(Mn)]},{['penalty=',pen]},vecCn(k),{['nu=',num2str(nu),' in delta_n']}])
% Result=[Theta_o_star',mehatTheta1(:,:,k)',Bias(:,:,k)',SE(:,:,k)',SD(:,:,k)',CP(:,:,k)'];
% resultTable = array2table(Result, ...
%     'VariableNames', {'Theta*','hatTheta','Bias','SE','SD','CP'});
% disp(resultTable)
acctable=array2table(PMn_star(:,:,k),'VariableNames',{'hatMn','count','percent (%)'});
disp(acctable)
% ans1=mean(rehatTheta111(:,:,k));
% bias=norm(ans1(:,[Mn+1+Mn+1:Mn+1+Mn+d1-1,Mn+1+Mn+d1-1+2:Mn+1+Mn+d1-1+d2+1])-[Beta_star(2:end),Eta_star(2:end)]);
% PEtable=array2table([bias,norm(Bias(:,:,k)),mean(reRMSE(:,:,k))],'VariableNames',...
%     {'||hatBeta-Beta*||+||hatGamma-Gamma*||','||hatTheat-Theta*||','PE (train)','PE (test)','R2 (train)','R2 (test)','mean(hatMn)'});
% disp(PEtable)
% disp(array2table(mean(reruntime),'VariableNames',{'Average calculation time (second)'}))


disp('Penalized smoothing least squares eatimator')
k=2;
if strcmp(varphi_type,'LSIR') 

disp([{['Mn=',num2str(Mn)]},{['penalty=',pen]},vecCn(k),{['nu=',num2str(nu),' in delta_n']}])
alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:Mn_star+1
    alpha_cell{s1}=['alpha',num2str(s1-1)];
end
for s2=1:Mn_star
    tau_cell{s2}=['tau',num2str(s2)];
end
for s3=1:d1-1
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:d2+1
    gamma_cell{s4}=['gamma',num2str(s4-1)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
Result=[Theta_o_star',mehatTheta1(:,:,k)',Bias(:,:,k)',SE(:,:,k)',SD(:,:,k)',CP(:,:,k)'];
resultTable = array2table(Result, ...
    'VariableNames', {'Theta*','hatTheta','Bias','SE','SD','CP'},'RowNames', row_labels);
disp(resultTable)
acctable=array2table(PMn_star(:,:,k),'VariableNames',{'hatMn','count','percent (%)'});
disp(acctable)
end

normBias=norm(Bias(:,:,k));
ans3=mean(reRMSE(:,:,k));
PE=ans3(:,2);



ans1=mean(rehatTheta111(:,:,k));
EE=norm(ans1(:,[Mn+1+Mn+1:Mn+1+Mn+d1-1,Mn+1+Mn+d1-1+2:Mn+1+Mn+d1-1+d2+1])-[Beta_star(2:end),Eta_star(2:end)]);
PEtable=array2table([EE,norm(Bias(:,:,k)),mean(reRMSE(:,:,k))],'VariableNames',...
    {'||hatBeta-Beta*||+||hatGamma-Gamma*||','||hatTheat-Theta*||','PE (train)','PE (test)*','R2 (train)','R2 (test)','mean(hatMn)'});
disp(PEtable)
disp(array2table(mean(reruntime)/B,'VariableNames',{'Average calculation time (second)'}))

save(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
