function filename=myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type)

filename=['Case',num2str(example),'-varphi-',varphi_type,'-Mn-',num2str(Mn),...
    '-sigma-',num2str(sigma_star),'-n-',num2str(n),'-n1-',num2str(n1),'-',pen,'-deltan-c1-',num2str(c1),'-nu-',num2str(nu),'.mat'];



