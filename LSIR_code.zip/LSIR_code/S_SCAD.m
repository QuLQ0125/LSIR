function eta=S_SCAD(zeta,lambda,t,vartheta)
%%%---SCAD---%%%
if t<=1+1/vartheta
    fprintf('t>1+1/vartheta?\n')
else
    
eta=ST(zeta,lambda/vartheta,t,vartheta).*(abs(zeta)<=lambda+lambda/vartheta)+...
    (ST(zeta,(t*lambda)/((t-1)*vartheta),t,vartheta))./(1-1/((t-1)*vartheta)).*(abs(zeta)>lambda+lambda/vartheta & abs(zeta)<=t*lambda)+...
    zeta.*(abs(zeta)>t*lambda);
end
