This is the Matlab code for Table S23.


The matlab codes:

main_taipei_LSIR_SCAD.m: This file is used to calculate the estimated values of the LSIR model and the value of R^2 on the real estate valuation dataset, where the penalty function is SCAD.

main_taipei_LSIR_SCAD_cv.m: This file is used to calculate the value of PE on the real estate valuation  dataset, where the penalty function is SCAD.

main_taipei_LSIR_MCP.m: This file is used to calculate the estimated values of the LSIR model and the value of R^2 on the real estate valuation dataset, where the penalty function is MCP.

main_taipei_LSIR_MCP_cv.m: This file is used to calculate the value of PE on the real estate valuation  dataset, where the penalty function is MCP.

main_taipei_PLSIR_cv.m: This file is used to calculate the estimated values of the PLSIR model and the values of PE and R^2 on the real estate valuation dataset.

main_taipei_LR_cv.m: This file is used to calculate the estimated values of the LR model and the values of PE and R^2 on the real estate valuation dataset.

result_TableS23.m: This file is used to obtain Table S23.


You can directly carry out the code: main_TableS23.m.


