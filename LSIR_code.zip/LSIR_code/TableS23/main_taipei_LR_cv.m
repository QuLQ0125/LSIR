clc;clear;close all
%%%---taipei_LR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];
%%%-------%%%

numSamples = size(X, 1);
indices = [1:n];
X=X(indices,:);Z=Z(indices,:);y=y(indices,:);

train_rate=1;
X_train=X(1:ceil(train_rate*numSamples),:);
Z_train=Z(1:ceil(train_rate*numSamples),:);
y_train=y(1:ceil(train_rate*numSamples),:);
n_train=size(X_train,1);
X_test=X(ceil(train_rate*numSamples)+1:end,:);
Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
y_test=y(ceil(train_rate*numSamples)+1:end,:);
n_test=size(X_test,1);


cvRMSE=[];cvhatbg=[];
numSamples_train = size(X_train, 1);
rng(123);
indices_train = randperm(numSamples_train);
X_train=X_train(indices_train,:);Z_train=Z_train(indices_train,:);y_train=y_train(indices_train,:);
cross_k=5;
foldSize = floor(numSamples_train / cross_k);
cvIndices = cell(cross_k, 1);
for i1 = 1:cross_k
    startIdx = (i1 - 1) * foldSize + 1;
    endIdx = i1 * foldSize;
    if i1 == cross_k
        endIdx = numSamples_train;
    end
    cvIndices{i1} = startIdx:endIdx;
end
    for r=1:5
        testIdx_r = cvIndices{r};
        trainIdx_r = setdiff(1:numSamples_train, testIdx_r);
        X_train_r = X_train(trainIdx_r, :);
        Z_train_r = Z_train(trainIdx_r, :);
        y_train_r = y_train(trainIdx_r);
        X_test_r = X_train(testIdx_r, :);
        Z_test_r=Z_train(testIdx_r, :);
        y_test_r = y_train(testIdx_r);
        
        
        XZ_train_r=[X_train_r,ones(size(X_train_r,1),1),Z_train_r];
        bg_r=(XZ_train_r'*XZ_train_r)\(XZ_train_r'*y_train_r);
       
        RMSE_train_r=sqrt(mean((y_train_r-XZ_train_r*bg_r).^2));
        ESS_train_r=sum((y_train_r-XZ_train_r*bg_r).^2);
        TSS_train_r=sum((y_train_r-mean(y_train_r)).^2);
        R2_train_r=1-ESS_train_r/TSS_train_r;
        
        XZ_test_r=[X_test_r,ones(size(X_test_r,1),1),Z_test_r];
        RMSE_test_r=sqrt(mean((y_test_r-XZ_test_r*bg_r).^2));
        ESS_test_r=sum((y_test_r-XZ_test_r*bg_r).^2);
        TSS_test_r=sum((y_test_r-mean(y_test_r)).^2);
        R2_test_r=1-ESS_test_r/TSS_test_r;
        %plot(X*[1;hatBeta1_r],y-Z*hatGamma1_r,'.',X*[1;hatBeta1_r],hatf_fun_r(X*[1;hatBeta1_r]),'.')
        cvRMSE(r,:)=[RMSE_train_r,RMSE_test_r,R2_train_r,R2_test_r];
        cvhatbg(:,r)=bg_r;
        
    end
    
reRMSE_h=mean(cvRMSE);
    
XZ_train=[X_train,ones(size(X_train,1),1),Z_train];
bg=(XZ_train'*XZ_train)\(XZ_train'*y_train);

RMSE_LR_train=sqrt(mean((y_train-XZ_train*bg).^2));
ESS_LR_train=sum((y_train-XZ_train*bg).^2);
TSS_LR_train=sum((y_train-mean(y_train)).^2);
R2_LR_train=1-ESS_LR_train/TSS_LR_train;

hatGamma1=bg(size(X_train,2)+2:end);
hatBeta1wan=bg(1:size(X_train,2));
hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
hatalpha0=hatBeta1wan(1);
u=linspace(min(X_train*[1;hatBeta1]),max(X_train*[1;hatBeta1]),100);
hatgamma0=bg(size(X_train,2)+1);
hatf_fun=@(w) hatgamma0+hatalpha0*w;


disp('Linear regression model (LR)')
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'PE (test)','R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',reRMSE_h(1,2),R2_LR_train],'VariableNames',col_labels);
disp(PEtable)
PE=reRMSE_h(1,2);
save('taipei_LR_est_cv')