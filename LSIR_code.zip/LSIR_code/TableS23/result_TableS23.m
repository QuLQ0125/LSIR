vecMn=[3,5,7,10];
result_TableS23_SCAD=[];
for i_Mn1=1:length(vecMn)
    Mn=vecMn(i_Mn1);
    load(['Mn-',num2str(Mn),'taipei_LSIR_est_SCAD.mat']);
    result_TableS23_SCAD(i_Mn1,1)=results_LSIR.hateta(1);
    result_TableS23_SCAD(i_Mn1,[2,3])=results_LSIR.hatalpha';
    result_TableS23_SCAD(i_Mn1,4)=results_LSIR.hattau';
    result_TableS23_SCAD(i_Mn1,5)=results_LSIR.hatbeta(2:end)';
    result_TableS23_SCAD(i_Mn1,[6,7])=results_LSIR.hateta(2:end)';
    result_TableS23_SCAD(i_Mn1,9)=results_LSIR.R2;
    load(['Mn-',num2str(Mn),'taipei_LSIR_est_SCAD_cv.mat']);
    result_TableS23_SCAD(i_Mn1,8)=PE;
end


result_TableS23_MCP=[];
for i_Mn1=1:length(vecMn)
    Mn=vecMn(i_Mn1);
    load(['Mn-',num2str(Mn),'taipei_LSIR_est_MCP.mat']);
    result_TableS23_MCP(i_Mn1,1)=results_LSIR.hateta(1);
    result_TableS23_MCP(i_Mn1,[2,3])=results_LSIR.hatalpha';
    result_TableS23_MCP(i_Mn1,4)=results_LSIR.hattau';
    result_TableS23_MCP(i_Mn1,5)=results_LSIR.hatbeta(2:end)';
    result_TableS23_MCP(i_Mn1,[6,7])=results_LSIR.hateta(2:end)';
    result_TableS23_MCP(i_Mn1,9)=results_LSIR.R2;
    load(['Mn-',num2str(Mn),'taipei_LSIR_est_MCP_cv.mat']);
    result_TableS23_MCP(i_Mn1,8)=PE;
end

result_TableS23_PLSIR=[];
load('taipei_PLSIR_est_cv.mat')
result_TableS23_PLSIR(:,5)=hatBeta1';
result_TableS23_PLSIR(:,[6,7])=hatGamma1';
result_TableS23_PLSIR(:,8)=PE;
result_TableS23_PLSIR(:,9)=R2_train;

result_TableS23_LR=[];
load('taipei_LR_est_cv.mat')
result_TableS23_LR(:,1)=hatgamma0;
result_TableS23_LR(:,2)=hatalpha0;
result_TableS23_LR(:,5)=hatBeta1';
result_TableS23_LR(:,[6,7])=hatGamma1';
result_TableS23_LR(:,8)=PE;
result_TableS23_LR(:,9)=R2_LR_train;

TableS23=[result_TableS23_SCAD;result_TableS23_MCP;result_TableS23_LR;result_TableS23_PLSIR];

row_labels={'SCAD-Mn3','SCAD-Mn5','SCAD-Mn7','SCAD-Mn10',...
           'MCP-Mn3','MCP-Mn5','MCP-Mn7','MCP-Mn10',...
           'LR','PLSIR'};
col_labels={'gamma0','alpha0','alpha1','tau1','beta2','gamma1','gamma2','PE','R^2'};
TableS23_tabletype = array2table(TableS23, ...
    'VariableNames',col_labels,'RowNames', row_labels)
