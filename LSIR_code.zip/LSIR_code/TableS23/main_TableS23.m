clc;clear;close all
main_taipei_LSIR_SCAD

main_taipei_LSIR_SCAD_cv

main_taipei_LSIR_MCP

main_taipei_LSIR_MCP_cv

main_taipei_LR_cv

main_taipei_PLSIR_cv

clc
result_TableS23