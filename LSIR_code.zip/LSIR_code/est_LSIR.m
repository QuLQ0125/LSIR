function results_LSIR=est_LSIR(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambdawan,t,deltan,cn,pen,maxiter,tol,B,ifplot)
% Z,X,y: The train data.
% Mn: The number of knots to be selected.
% Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1: The initial values.
% Lambdawan: Some tuning parameter.
% t: A parameter that controls the concavity of the penalty function.
% deltan. The smoothness parameter.
% cn:  A predetermined constant in BIC.
% pen: A type of penalty function, i.e. 'SCAD' and 'MCP' .
% maxiter: The maximum number of iterations.
% tol:  The tolerance parameter.
% B: The bootstrap sampling times..
% ifplot: Whether to draw or not, i.e. 'true', 'flase'.

%%%---estimate---%%%
[ansBIC,hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,hatAlpha111,hatTau111,BICmin]=...
    Global_ADMM(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambdawan,t,deltan,cn,pen,maxiter,tol,B);

hatMn=BICmin(2);

[hatSE,hatsigma2,hatXI,hatV]=est_SE(y,Z,X,hatEta1,hatBeta11,hatAlpha1,hatTau1,hatlambda,deltan,t,pen);

n=size(X,1);
Q0=[];
T0=X*hatBeta11;
Q0=[T0,f0(T0,hatTau1')];
ESS=sum((y-[ones(n,1),Z]*hatEta1-Q0*hatAlpha1).^2);
TSS=sum((y-mean(y)).^2);
R2=1-ESS/TSS;
RMSE=sqrt(mean((y-[ones(n,1),Z]*hatEta1-Q0*hatAlpha1).^2));

hatTheta1=[hatAlpha1;hatTau1;hatBeta11(2:end);hatEta1];
pvalue=2*(1-normcdf(abs(hatTheta1./hatSE)));
CI=[hatTheta1-1.96*hatSE,hatTheta1+1.96*hatSE];
Result=[hatTheta1,hatSE,hatTheta1-1.96*hatSE,hatTheta1+1.96*hatSE,pvalue];

%%%---testing---%%%
[hatEta1_oracle_0,hatBeta11_oracle_0,hatAlpha1_oracle_0,hatTau1_oracle_0]=est_oracle(Z,X,y,0,Beta0wan1,Eta0wan1,[],0,deltan,500,1e-4);
% vectau0=linspace(-2,0.5,100);
vectau0=linspace(min(hatTau111)-1,max(hatTau111)+0.5,100);
varpim=0;
pvalue_knot=test_knots(y,Z,X,hatEta1_oracle_0,hatBeta11_oracle_0,hatAlpha1_oracle_0,hatTau1_oracle_0,deltan,vectau0,varpim,0);



%%%---output---%%%
disp('Penalized smoothing least squares eatimator')
disp(['Mn=',num2str(Mn),', penalty=',pen])

alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:length(hatAlpha1)
    alpha_cell{s1}=['alpha',num2str(s1-1)];
end
for s2=1:length(hatTau1)
    tau_cell{s2}=['tau',num2str(s2)];
end
for s3=1:length(hatBeta11(2:end))
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatEta1)
    gamma_cell{s4}=['gamma',num2str(s4-1)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
resultTable = array2table(Result, ...
    'VariableNames', {'hatTheta','SE','Low-CI','Upper-CI','p-value'},'RowNames', row_labels);
disp(resultTable)

R2table=array2table([R2,hatMn],'VariableNames',...
    {'R2 (all-set)','hatMn'});
disp(R2table)

disp(array2table(pvalue_knot,'VariableNames',...
    {'p-value of testing for knot effects'}))


results_LSIR=[];
results_LSIR.resultTable=resultTable;
results_LSIR.hatalpha=hatAlpha1;
results_LSIR.hatbeta=hatBeta11;
results_LSIR.hattau=hatTau1;
results_LSIR.hateta=hatEta1;
results_LSIR.pvalue=pvalue;
results_LSIR.SE=hatSE;
results_LSIR.CI=CI;
results_LSIR.R2=R2;
results_LSIR.hatMn=hatMn;
results_LSIR.pvalue_knot=pvalue_knot;
results_LSIR.BIC_lambda=ansBIC;
results_LSIR.hatlambda=BICmin(1);




%%%---figure---%%%
if strcmp(ifplot,'true') || strcmp(ifplot,'True')
    figure;
    hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau111')]*hatAlpha111;
    plot(X*hatBeta11,y-Z*hatEta1(2:end),'.',sort(X*hatBeta11),hatvarphi(sort(X*hatBeta11)),'-','Linewidth',2.5)
    xlabel('${X}_i^\top\widehat{\beta}$','interpreter','latex','Fontname','Times New Roman')
    ylabel('$Y_i-{Z}_i^\top\mathbf{\widehat\gamma}$','interpreter','latex','Fontname','Times New Roman')
    
    
    figure;
    [~,h]=min(ansBIC(:,3));
    BICmin_plot=ansBIC(h,1:3);
    subplot(1,2,1)
    plot(ansBIC(:,1),ansBIC(:,2))
    hold on;plot(BICmin_plot(1),BICmin_plot(2),'ko')
    text(BICmin_plot(1),BICmin_plot(2)-0.01,['(',num2str(BICmin_plot(1)),',',num2str(BICmin_plot(2)),')'])
    xlabel('$\lambda$','interpreter','latex')
    ylabel('$\hat M_n$','interpreter','latex')
    subplot(1,2,2)
    plot(ansBIC(:,1),ansBIC(:,3))
    hold on;plot(BICmin_plot(1),BICmin_plot(3),'ko')
    text(BICmin_plot(1),BICmin_plot(3)-0.001,['(',num2str(BICmin_plot(1)),',',num2str(BICmin_plot(3)),')'])
    
    xlabel('$\lambda$','interpreter','latex')
    ylabel('BIC','interpreter','latex')

end
