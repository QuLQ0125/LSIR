function Q=qn(T,tau,deltan)

Q=0.*(T<tau-deltan)+(T-tau+deltan).^2/(4*deltan).*(T>=tau-deltan & T<=tau+deltan)+(T-tau).*(T>tau+deltan);
