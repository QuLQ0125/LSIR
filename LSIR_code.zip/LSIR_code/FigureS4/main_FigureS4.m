clc;clear;close all
main_simulation_S2

main_simulation_S3

clc
plot_FigureS4