This is the Matlab code for Figure S4.


The matlab codes:

main_simulation_S2.m: This file is used to calculate the estimated values of the LSIR model and the PLSIR model for Case S2.

main_simulation_S3.m: This file is used to calculate the estimated values of the LSIR model and the PLSIR model for Case S3.

CaseS2.m: This file is the setting for Case S2.

CaseS3.m: This file is the setting for Case S3.

mygendate.m, gendata.m are used to generate simulated data.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

Simulation_PLSIR.m: This file includes specific calculation steps for PLSIR model.

myfilename.m: This file is used to determine the saving path for the calculation results.

plot_FigureS4.m: This file is used to draw Figure S4.



You can directly carry out the code: main_FigureS4.m.