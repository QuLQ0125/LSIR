README file for Matlab supporting the LSIR model.
Software version: Matlab R2020 b or R2021 a.
Encoding: UTF-8.

Contents of this archive
-----------------------------
This archive contains 
(1) Basic function: Some m-function files. 
(2) simulation folder: The m-file required for implementing the simulation.
(3) realdata folder: The m-file required for implementing the real data analysis.
(4) figure folder: The m-file required for figure.



(1) Basic function
est_LSIR.m 
Description:
This function can obtain estimated values of the parameters, and it combines the ADMM algorithm and bootstrap sampling.


Useage: Simply run this funtion on your favorite datasets.
results_LSIR=est_LSIR(Z,X,y,Mn,Beta_initial,Eta_initial,Tau_initial,Alpha_initial,Lambda,t,deltan,cn,pen,maxiter,tol,B,ifplot)


Arguments:
Z,X,y: The train data.
Mn: The number of knots to be selected.
Beta_initial,Eta_initial,Tau_initial,Alpha_initial: The initial values.
Lambda: Some tuning parameter.
t: A parameter that controls the concavity of the penalty function.
deltan. The smoothness parameter.
cn:  A predetermined constant in BIC.
pen: A type of penalty function, i.e. 'SCAD' and 'MCP' .
MI: The maximum number of iterations.
tol:  The tolerance parameter.
B: The bootstrap sampling times.
ifplot: Whether to draw or not, i.e. 'true', 'flase'.


Return:
results_LSIR is struct type, which inclues
resultTable: A table including estimate value, standard errors (SE), confidence interval (CI) and p-value.
hatalpha: The estimated value of alpha.
hatbeta: The estimated value of beta.
hattau: The estimated value of tau
hateta: The estimated value of eta
pvalue: The p-value of parameter.
SE: The standard errors (SE).
CI: The confidence interval (CI).
R2: The coefficient of determination.
hatMn: The estimated value of Mn*.
pvalue_knot: The p-value of testing for knot effects.
BIC_lambda: The BIC values corresponding to all lambdas.
hatlambda: The lambda value that minimizes the BIC.



(2) simulation folder
2.1 main_simulation.m
Description: This file can obtain simulated results of oracle, LSIR (SCAD),  LSIR (MCP), PLSIR and LR. The resylts conclus Bias, SE, SD, CP,  the percentage of correctly specified models, ||hatBeta-Beta*||+||hatGamma-Gamma*||,  the prediction erro (PE), and the average calculation time (second). For details, please refer to the instructions in the m-file. You can change different sample sizes, the numbers of knots to be selected, the smoothing parameters, and types of random errors to obtain different results. Therefore, this file can acquire Tables 1-4, Tables S1-S3 and Tables S5-S21. 


2.2 main_testing.m
Description: This file can obtain the power results of the test statistic. For details, please refer to the instructions in the m-file. You can change different sample sizes,  the smoothing parameters, and types of random errors to obtain different results. Therefore, this file can obtain Table 5.



(3) realdata folder
the following files works on the  fish toxicity dataset.
3.1.1 main_fish_LSIR_allset.m: This file can obtain the fitting coefficients R2 of all variable combinations by selecting SCHI in the file, as well as the estimates of the parameters.
3.1.2 main_fish_LSIR_cv.m: This file can obtain the prediction error (PE) of the five-fold cross-validation of the data on the LSIR model.
3.1.3 main_fish_PLSIR: This file can obtain the prediction error (PE) of the five-fold cross-validation of the data on the PLSIR model and the fitting situation of all the data.
3.1.4 main_fish_LR: This file can obtain the prediction error (PE) of the five-fold cross-validation of the data on the LR model and the fitting situation of all the data.
Therefore, these files can obtain Table 7 and Tables S24-S25. 

By using the following program statement in  file main_fish_LSIR_allset.m can obatin Table S4.
% redata1(373,:)=[];%removing a extreme data point


Similarly, the following files works on the real estate valuation dataset.
3.2.1 main_taipei_LSIR_allset.m
3.2.2 main_taipei_LSIR_cv.m
3.2.3 main_taipei_PLSIR
3.2.4 main_taipei_LR
These files can obtain Table 6 and Tables S22-S23.




(4) figure folder
These m-files can obtain figures 1-2 and figures S1-S9.

