vecMn=[4,5,5];sigma_star=1;example=3;
vecpen={'Oracle','SCAD','MCP'};c1=1;varphi_type='LSIR';


n=1250;nu=0.7;
Table_n1000_nu07=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n1000_nu07=[Table_n1000_nu07,Result(:,3:end)];
end
Table_n1000_nu07(end-1,:)=[];


n=2500;nu=0.7;
Table_n2000_nu07=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n2000_nu07=[Table_n2000_nu07,Result(:,3:end)];
end
Table_n2000_nu07(end-1,:)=[];


Table4=[Table_n1000_nu07;Table_n2000_nu07]*100;


col_labels={'Oracle-Bias','Oracle-SE','Oracle-SD','Oracle-CP',...
    'SCAD-Bias','SCAD-SE','SCAD-SD','SACD-CP',...
    'MCP-Bias','MCP-SE','MCP-SD','MCP-CP'};
Table4_tabletype = array2table(Table4, ...
    'VariableNames',col_labels)
