This is the Matlab code for Figure S7, Tables 1-4 and Tables S5-S20.


The matlab codes:

main_simulation_Case1.m: This file is used to calculate the values of LSIR model for Case 1.

main_simulation_Case2.m: This file is used to calculate the values of LSIR model for Case 2.

main_simulation_Case3.m: This file is used to calculate the values of LSIR model for Case 3.

Case1.m: This file is the setting for Case 1.

Case2.m: This file is the setting for Case 2.

Case3.m: This file is the setting for Case 3.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m and Simulation_oracle.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

Simulation_oracle.m: This file includes specific calculation steps for oracle estimator.

myfilename.m: This file is used to determine the saving path for the calculation results.

plot_FigureS7.m: This file is used to draw Figure S7.

result_Table1.m-result_Table4.m: These files are used to obtain Tables 1-4.

result_TableS5.m-result_TableS20.m: These files are used to obtain Tables S5-S20.



You can directly carry out the code: main_FigureS7_Tables1_4_TablesS5_S20.m.

