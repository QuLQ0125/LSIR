t = tiledlayout(3, 3, 'TileSpacing', 'loose', 'Padding', 'loose');
%n1=2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%case 1
nexttile; 
data=[];
vecMn=[1,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=1;example=1;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;


n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)




set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')

ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(a) Case 1 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0:0.1:1];
% yticks(desired_yticks);
% ylim([0.4,0.8])
xlim([-0.15,2.15])




nexttile; 
data=[];
vecMn=[1,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=22;example=1;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;

n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(b) Case 1 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0.1:0.2:0.7];
% yticks(desired_yticks);
% ylim([0.1,0.7])
xlim([-0.15,2.15])




nexttile; 
data=[];
vecMn=[1,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=41;example=1;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(c) Case 1 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0:0.3:2];
% yticks(desired_yticks);
% ylim([0,1.2])
xlim([-0.15,2.15])



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case 2
nexttile; 
data=[];
vecMn=[2,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=1;example=2;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(d) Case 2 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0.6:0.3:2];
% yticks(desired_yticks);
% ylim([0.6,1.8])
xlim([-0.15,2.15])



nexttile; 
data=[];
vecMn=[2,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=22;example=2;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(e) Case 2 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0.5:0.5:4];
% yticks(desired_yticks);
% ylim([0.5,3])
xlim([-0.15,2.15])




nexttile; 
data=[];
vecMn=[2,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=41;example=2;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(f) Case 2 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0:1:5];
% yticks(desired_yticks);
% ylim([1,5])
xlim([-0.15,2.15])




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case 3
nexttile; 
data=[];
vecMn=[4,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=1;example=3;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(g) Case 3 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0.5:1:4];
% yticks(desired_yticks);
% ylim([0.5,3.5])
xlim([-0.15,2.15])



nexttile; 
data=[];
vecMn=[4,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=22;example=3;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(h) Case 3 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0:0.5:4];
% yticks(desired_yticks);
% ylim([1,3])
xlim([-0.15,2.15])




nexttile; 
data=[];
vecMn=[4,5,5];vecn=[1250,1250,1250,2500,2500,2500];sigma_star=41;example=3;
vecpen={'Oracle','SCAD','MCP',};c1=1;vecnu=[0.6,0.7,0.8,0.6,0.7,0.8];varphi_type='LSIR';
for i_nu=1:length(vecnu)
    for j_pen=1:length(vecpen)
        n=vecn(i_nu);
        pen=vecpen{j_pen};
        nu=vecnu(i_nu);
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        data(i_nu,j_pen)=normBias;
    end
end
data=data*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(i) Case 3 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
% desired_yticks =[0:1:8];
% yticks(desired_yticks);
% ylim([2,7])
xlim([-0.15,2.15])




% % % Draw the legend
legendData = {'$(n,\nu)=(1000,0.6)$','$(n,\nu)=(1000,0.7)$','$(n,\nu)=(1000,0.8)$','$(n,\nu)=(2000,0.6)$','$(n,\nu)=(2000,0.7)$', '$(n,\nu)=(2000,0.8)$'};
legend(legendData )
set(legend,'interpreter','latex','Fontsize',22,'Fontname','Times New Roman',...
    'LineWidth',0.75,'Orientation', 'horizontal')

lgd=legend();
lgd.Layout.Tile = 'south';



