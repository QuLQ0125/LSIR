clc;clear;close all
main_simulation_Case1

main_simulation_Case2

main_simulation_Case3

clc
plot_FigureS7
result_Table1
result_Table2
result_Table3
result_Table4
result_TableS5
result_TableS6
result_TableS7
result_TableS8
result_TableS9
result_TableS10
result_TableS11
result_TableS12
result_TableS13
result_TableS14
result_TableS15
result_TableS16
result_TableS17
result_TableS18
result_TableS19
result_TableS20


