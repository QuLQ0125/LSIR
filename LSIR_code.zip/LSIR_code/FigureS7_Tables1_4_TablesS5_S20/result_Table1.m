Mn=5;vecn=[1250,1250,2500,2500,1250,1250,2500,2500,1250,1250,2500,2500];
example=1;vecpen={'SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP'};
c1=1;vecnu=[0.6,0.6,0.6,0.6,0.7,0.7,0.7,0.7,0.8,0.8,0.8,0.8];varphi_type='LSIR';


sigma_star=1;
result_Table_normal=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_normal(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_normal(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


sigma_star=22;
result_Table_schi2=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_schi2(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_schi2(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


sigma_star=41;
result_Table_t4=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_t4(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_t4(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


Table1=[result_Table_normal,result_Table_schi2,result_Table_t4];


row_labels={'nu0.6-n1000-SCAD','nu0.6-n1000-MCP','nu0.6-n2000-SCAD','nu0.6-n2000-MCP',...
            'nu0.7-n1000-SCAD','nu0.7-n1000-MCP','nu0.7-n2000-SCAD','nu0.7-n2000-MCP',...
            'nu0.8-n1000-SCAD','nu0.8-n1000-MCP','nu0.8-n2000-SCAD','nu0.8-n2000-MCP'};
col_labels={'N(0,1)-cn-1','N(0,1)-cn-loglogn','Schi^2(2)-cn-1','Schi^2(2)-cn-loglogn','t(4)-cn-1','t(4)-cn-loglogn'};
Table1_tabletype = array2table(Table1, ...
    'VariableNames',col_labels,'RowNames', row_labels)
