Mn=5;vecn=[1250,1250,2500,2500,1250,1250,2500,2500,1250,1250,2500,2500];
vecpen={'SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP'};
c1=1;vecnu=[0.6,0.6,0.6,0.6,0.7,0.7,0.7,0.7,0.8,0.8,0.8,0.8];varphi_type='LSIR';


example=2;sigma_star=1;
result_Table_Case2_normal=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_Case2_normal(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_Case2_normal(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


example=2;sigma_star=22;
result_Table_Case2_schi2=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_Case2_schi2(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_Case2_schi2(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


example=2;sigma_star=41;
result_Table_Case2_t4=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_Case2_t4(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_Case2_t4(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


TableS5_Case2=[result_Table_Case2_normal,result_Table_Case2_schi2,result_Table_Case2_t4];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Mn=5;vecn=[1250,1250,2500,2500,1250,1250,2500,2500,1250,1250,2500,2500];
vecpen={'SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP','SCAD','MCP'};
c1=1;vecnu=[0.6,0.6,0.6,0.6,0.7,0.7,0.7,0.7,0.8,0.8,0.8,0.8];varphi_type='LSIR';


example=3;sigma_star=1;
result_Table_Case3_normal=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_Case3_normal(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_Case3_normal(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


example=3;sigma_star=22;
result_TableS_Case3_schi2=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_TableS_Case3_schi2(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_TableS_Case3_schi2(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


example=3;sigma_star=41;
result_Table_Case3_t4=[];
for i_pen=1:length(vecpen)
    n=vecn(i_pen);
    pen=vecpen{i_pen};
    nu=vecnu(i_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type))
    result_Table_Case3_t4(i_pen,1)=PMn_star(find(PMn_star(:,1,1)==Mn_star),3,1);
    result_Table_Case3_t4(i_pen,2)=PMn_star(find(PMn_star(:,1,2)==Mn_star),3,2);
end


TableS5_Case3=[result_Table_Case3_normal,result_TableS_Case3_schi2,result_Table_Case3_t4];


TableS5=[TableS5_Case2;TableS5_Case3];


row_labels={'Case2-nu0.6-n1000-SCAD','Case2-nu0.6-n1000-MCP','Case2-nu0.6-n2000-SCAD','Case2-nu0.6-n2000-MCP',...
            'Case2-nu0.7-n1000-SCAD','Case2-nu0.7-n1000-MCP','Case2-nu0.7-n2000-SCAD','Case2-nu0.7-n2000-MCP',...
            'Case2-nu0.8-n1000-SCAD','Case2-nu0.8-n1000-MCP','Case2-nu0.8-n2000-SCAD','Case2-nu0.8-n2000-MCP',...
            'Case3-nu0.6-n1000-SCAD','Case3-nu0.6-n1000-MCP','Case3-nu0.6-n2000-SCAD','Case3-nu0.6-n2000-MCP',...
            'Case3-nu0.7-n1000-SCAD','Case3-nu0.7-n1000-MCP','Case3-nu0.7-n2000-SCAD','Case3-nu0.7-n2000-MCP',...
            'Case3-nu0.8-n1000-SCAD','Case3-nu0.8-n1000-MCP','Case3-nu0.8-n2000-SCAD','Case3-nu0.8-n2000-MCP'};
col_labels={'N(0,1)-cn-1','N(0,1)-cn-loglogn','Schi^2(2)-cn-1','Schi^2(2)-cn-loglogn','t(4)-cn-1','t(4)-cn-loglogn'};
TableS5_tabletype = array2table(TableS5, ...
    'VariableNames',col_labels,'RowNames', row_labels)
