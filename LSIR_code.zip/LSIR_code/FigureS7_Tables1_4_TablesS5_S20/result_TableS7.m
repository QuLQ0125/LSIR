sigma_star=41;vecMn=[1,5,5];example=1;
vecpen={'Oracle','SCAD','MCP'};c1=1;varphi_type='LSIR';


n=1250;nu=0.6;
Table_n1000_nu06=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n1000_nu06=[Table_n1000_nu06,Result(:,3:end)];
end
Table_n1000_nu06(end-1,:)=[];


%%%%%%%%%%%%%%%%%%%
n=1250;nu=0.7;
Table_n1000_nu07=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n1000_nu07=[Table_n1000_nu07,Result(:,3:end)];
end
Table_n1000_nu07(end-1,:)=[];


%%%%%%%%%%%%%%%%%%%
n=1250;nu=0.8;
Table_n1000_nu08=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n1000_nu08=[Table_n1000_nu08,Result(:,3:end)];
end
Table_n1000_nu08(end-1,:)=[];


%%%%%%%%%%%%%%%%%%%
n=2500;nu=0.6;
Table_n2000_nu06=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n2000_nu06=[Table_n2000_nu06,Result(:,3:end)];
end
Table_n2000_nu06(end-1,:)=[];


%%%%%%%%%%%%%%%%%%%
n=2500;nu=0.7;
Table_n2000_nu07=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n2000_nu07=[Table_n2000_nu07,Result(:,3:end)];
end
Table_n2000_nu07(end-1,:)=[];


%%%%%%%%%%%%%%%%%%%
n=2500;nu=0.8;
Table_n2000_nu08=[];
for j_pen=1:length(vecpen)
    pen=vecpen{j_pen};
    Mn=vecMn(j_pen);
    load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
    Table_n2000_nu08=[Table_n2000_nu08,Result(:,3:end)];
end
Table_n2000_nu08(end-1,:)=[];


TableS7=[Table_n1000_nu06;Table_n1000_nu07;Table_n1000_nu08;...
    Table_n2000_nu06;Table_n2000_nu07;Table_n2000_nu08];



col_labels={'Oracle-Bias','Oracle-SE','Oracle-SD','Oracle-CP',...
    'SCAD-Bias','SCAD-SE','SCAD-SD','SACD-CP',...
    'MCP-Bias','MCP-SE','MCP-SD','MCP-CP'};
TableS7_tabletype = array2table(TableS7, ...
    'VariableNames',col_labels)
