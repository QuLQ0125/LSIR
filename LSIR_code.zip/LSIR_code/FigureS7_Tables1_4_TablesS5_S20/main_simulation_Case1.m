clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

[example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=Case1();%Case 1-Case 3 and Case S1-Case S3

%%%---input---%%%
n1=1000;%the replications times>1
Mn=5;%the number of knots to be selected, Mn=3 5 7 10
c1=1;%$\delta_n=c1*(log(Mn+1)/n)^nu$
B=2;%the bootstrap sampling times

sigma_star=1;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)
n=1250;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


%%%---input---%%%
n=2500;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)





%%%---Schi^2(2)---%%%

%%%---input---%%%
sigma_star=22;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)
n=1250;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


%%%---input---%%%
n=2500;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)




%%%---t(4)---%%%
%%%---input---%%%
sigma_star=41;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)
n=1250;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


%%%---input---%%%
n=2500;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set

%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);

nu=0.6;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.7;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


nu=0.8;
calfun(c1,nu,Mn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)