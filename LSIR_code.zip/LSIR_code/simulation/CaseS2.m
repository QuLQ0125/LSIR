function [example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=CaseS2()
example=11;
d2=1;
d1=2;
meanZ=zeros(1,d2);
meanX=zeros(1,d1);
sigmaZ=eye(d2)*0.5+ones(d2)*0.5;
sigmaX=eye(d1)*0.5+ones(d1)*0.5;
Eta_star=[0;0.5];
Beta_star=[1;-1];
Alpha_star=[-1;1.5];
Tau_star=[0];
Mn_star=length(Tau_star);
sn_star=d1+d2+Mn_star+1+Mn_star;
D=100;
Theta_o_star=[Alpha_star',Tau_star',Beta_star(2:end)',Eta_star'];
% varphi=@(w) Eta_star(1)+[w,f0(w,Tau_star')]*Alpha_star;varphi_type='LSIR';
varphi=@(w) 0.25*w.^2;varphi_type='nonlinear-0.25';

