function Simulation_oracle(Mn,Lambdawan,t,deltan,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type)
%%%---oracle---%%%
rehatsigma2=[];rehatV=[];
rehatTheta1=[];rehatSE=[];J=[];
reansBIC=[];reruntime=[];
rehatXI=[];


Beta0wan1=[];Eta0wan1=[];Tau0wan1=[];
Beta0wan1=Beta_star(2:end)+0.1*ones(size(Beta_star,1)-1,1);
Eta0wan1=Eta_star-0.1*ones(size(Eta_star,1),1);
Tau0wan1=Tau_star-0.1;


iter=1;
while(iter<=n1)
    iter
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    n_train=size(X_train,1);
    X_test=X(ceil(train_rate*numSamples)+1:end,:);
    Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
    y_test=y(ceil(train_rate*numSamples)+1:end,:);
    n_test=size(X_test,1);
    
    tic
    [hatEta1,hatBeta11,hatAlpha1,hatTau1,myBIC]=est_oracle(Z_train,X_train,y_train,Mn,Beta0wan1,Eta0wan1,Tau0wan1,zeros(Mn+1,1),deltan,500,1e-4);
    reruntime(iter,:)=toc;
    reansBIC(iter,:)=myBIC;
    [hatSE,hatsigma2,hatXI,hatV]=est_SE(y_train,Z_train,X_train,hatEta1,hatBeta11,hatAlpha1,hatTau1,Lambdawan,deltan,t,'MCP');
    rehatTheta1(iter,:)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1'];
    J(iter,:)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1']-Theta_o_star;
    
    rehatXI(:,:,iter)=hatXI;
    rehatsigma2(iter,:)=hatsigma2;
    rehatV(:,:,iter)=hatV;
    rehatSE(iter,:)=hatSE';
    
    hatQ0_train=[];
    hatT0_train=X_train*hatBeta11;
    hatQ0_train=[hatT0_train,f0(hatT0_train,hatTau1')];
    RMSE_train=sqrt(mean((y_train-[ones(n_train,1),Z_train]*hatEta1-hatQ0_train*hatAlpha1).^2));
    ESS_train=sum((y_train-[ones(n_train,1),Z_train]*hatEta1-hatQ0_train*hatAlpha1).^2);
    TSS_train=sum((y_train-mean(y_train)).^2);
    R2_train=1-ESS_train/TSS_train;
    
    hatQ0_test=[];
    hatT0_test=X_test*hatBeta11;
    hatQ0_test=[hatT0_test,f0(hatT0_test,hatTau1')];
    RMSE_test=sqrt(mean((y_test-[ones(n_test,1),Z_test]*hatEta1-hatQ0_test*hatAlpha1).^2));
    ESS_test=sum((y_test-[ones(n_test,1),Z_test]*hatEta1-hatQ0_test*hatAlpha1).^2);
    TSS_test=sum((y_test-mean(y_test)).^2);
    R2_test=1-ESS_test/TSS_test;
    
    reRMSE(iter,:)=[RMSE_train,RMSE_test,R2_train,R2_test];
    
    iter=iter+1;
end
mehatTheta1=mean(rehatTheta1,1);

Bias=mean(J);
SD=std(J);
SE=mean(rehatSE,1);
CP=mean(abs(J)./SE<=1.96);
%%%---output---%%%
disp('Oracle estimator')
if strcmp(varphi_type,'LSIR') 
alpha_cell={};tau_cell={};beta_cell={};gamma_cell={};
for s1=1:length(hatAlpha1)
    alpha_cell{s1}=['alpha',num2str(s1-1)];
end
for s2=1:length(hatTau1)
    tau_cell{s2}=['tau',num2str(s2)];
end
for s3=1:length(hatBeta11(2:end))
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatEta1)
    gamma_cell{s4}=['gamma',num2str(s4-1)];
end
row_labels=[alpha_cell,tau_cell,beta_cell,gamma_cell];
Result=[Theta_o_star',mehatTheta1',Bias',SE',SD',CP'];
resultTable = array2table(Result, ...
    'VariableNames', {'Theta*','hatTheta','Bias','SE','SD','CP'},'RowNames', row_labels);
disp(resultTable)
PEtable=array2table(mean(reRMSE),'VariableNames',{'PE (train)','PE (test)*','R2 (train)','R2 (test)'});
disp(PEtable)

end

