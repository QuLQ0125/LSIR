function Simulation_LR(pen,...
    n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type)
%%%---LR---%%%
rehatTheta1=[];J=[];rehatEpsilon=[];cvRMSE=[];cvhatBeta1=[];cvhatGamma1=[];
reruntime=[];reRMSE_h=[];rehatfun={};reh=[];reRMSE=[];ref_hat=[];redf_hat=[];reu=[];
recoefficients_hat=[];rehatfun={};rebg=[];

Beta0wan1=[];Eta0wan1=[];Tau0wan1=[];
Beta0wan1=Beta_star(2:end)+0.1*ones(size(Beta_star,1)-1,1);
Eta0wan1=Eta_star-0.1*ones(size(Eta_star,1),1);


iter=1;

while(iter<=n1)
    
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    
    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    n_train=size(X_train,1);
    X_test=X(ceil(train_rate*numSamples)+1:end,:);
    Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
    y_test=y(ceil(train_rate*numSamples)+1:end,:);
    n_test=size(X_test,1);
    XZ_train=[X_train,ones(size(X_train,1),1),Z_train];
    bg=(XZ_train'*XZ_train)\(XZ_train'*y_train);
    rebg(:,iter)=bg;

    hatGamma1=bg(size(X_train,2)+2:end);
    hatBeta1wan=bg(1:size(X_train,2));
    hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
    hatalpha0=hatBeta1wan(1);
    hatgamma0=bg(size(X_train,2)+1);
    hatf_fun=@(w) hatgamma0+hatalpha0*w;
    rehatfun{iter}=hatf_fun;%plot(X*[1;hatBeta1],y-Z*hatGamma1,'.',X*[1;hatBeta1],hatf_fun(X*[1;hatBeta1]),'.')
    %figure;plot(X*hatBeta1wan,y-Z*hatGamma1,'.',X*hatBeta1wan,hatgamma0+X*hatBeta1wan,'.')
    rehatEpsilon(:,iter)=y_train-XZ_train*bg;
    rehatTheta1(iter,:)=[hatBeta1',hatGamma1'];
    J(iter,:)=[hatBeta1',hatGamma1']-[Beta_star(2:end)',Eta_star(2:end)'];
    

    RMSE_LR_train=sqrt(mean((y_train-XZ_train*bg).^2));
    ESS_LR_train=sum((y_train-XZ_train*bg).^2);
    TSS_LR_train=sum((y_train-mean(y_train)).^2);
    R2_LR_train=1-ESS_LR_train/TSS_LR_train;
    
    XZ_test=[X_test,ones(size(X_test,1),1),Z_test];
    RMSE_LR_test=sqrt(mean((y_test-XZ_test*bg).^2));
    ESS_LR_test=sum((y_test-XZ_test*bg).^2);
    TSS_LR_test=sum((y_test-mean(y_test)).^2);
    R2_LR_test=1-ESS_LR_test/TSS_LR_test;
    
    reRMSE(iter,:)=[RMSE_LR_train,RMSE_LR_test,R2_LR_train,R2_LR_test];
    
    
    
    iter=iter+1;
end

ans1=J(:,1);
ans2=abs(ans1)<10;
J3=J(ans2,:);
rehatTheta2=rehatTheta1(ans2,:);
mehatTheta1=mean(rehatTheta2,1);
Bias=mean(J3);
% Bias=mean(J);
SD=std(J);
SE=SD;
CP=mean(abs(J)./SE<=1.96);


%%%---output---%%%
disp('Linear regression model (LR)')
Result=[[Beta_star(2:end);Eta_star(2:end)'],mehatTheta1',Bias',SD'];
resultTable = array2table(Result, ...
    'VariableNames', {'Theta*','hatTheta','Bias','SD'});
disp(resultTable)
PEtable=array2table([norm(Bias),mean(reRMSE)],'VariableNames',{'||hatBeta-Beta*||+||hatGamma-Gamma*||','PE (train)','PE (test)*','R2 (train)','R2 (test)'});
disp(PEtable)
