function hatCalpha=Simulation_test(Mn,nu,n1,Alpha_star,Beta_star,Eta_star,Tau_star,sigma_star,n1Z,n1X,n1y,deltan,vectau0,varpim,tilde_alpha)
rehatTheta1=[];J=[];reansBIC=[];
reruntime=[];
rehatVpsi=[];repsi=[];rehatEpsi=[];reT1=[];reT1_star_alpha=[];rem=[];
repvalue=[];
reT1_star=[];


iter=1;m=0;
Beta0wan1=[];Eta0wan1=[];Tau0wan1=[];
Beta0wan1=Beta_star(2:end)+0.1*ones(size(Beta_star,1)-1,1);%0.1*rand(size(Beta_star,1)-1,1);%[-0.4954;1.0184];
Eta0wan1=Eta_star-0.1*ones(size(Eta_star,1),1);%0.1*rand(size(Gamma_star,1),1);

while(iter<=n1)
    iter
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    
    tic
    [hatEta1,hatBeta11,hatAlpha1,hatTau1,myBIC]=est_oracle(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,zeros(Mn+1,1),deltan,500,1e-4);
    reruntime(iter,:)=toc;
    reansBIC(iter,:)=myBIC;

    [pvalue,T,T1_star_alpha,T1,T1_star,psi,hatEpsi,hatvar_rho]=test_knots(y,Z,X,hatEta1,hatBeta11,hatAlpha1,hatTau1,deltan,vectau0,varpim,Tau_star);
    repvalue(iter,:)=pvalue;
    reT1(iter,:)=T1';
    rehatVpsi(iter,:)=hatvar_rho';
    repsi(iter,:)=psi';
    rehatEpsi(iter,:)=hatEpsi';
    reT1_star(:,iter)=T1_star;%qqplot((supT1n_i-mean(supT1n_i))/std(supT1n_i))
    reT1_star_alpha(iter,:)=T1_star_alpha;
    rem(iter,:)=(T>T1_star_alpha);
    rehatTheta1(iter,:)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1'];
    J(iter,:)=[hatAlpha1',hatTau1',hatBeta11(2:end)',hatEta1']-[Alpha_star(1),Beta_star(2:end)',Eta_star'];
    
    iter=iter+1;
end
n=size(X,1);
mehatTheta1=mean(rehatTheta1,1);

Bias=mean(J);
SD=std(J);
SE=SD;
CP=mean(abs(J)./SE<=1.96);

Epsi=mean(repsi);
hatEpsi=mean(rehatEpsi);
SEpsi=mean(rehatVpsi);
SDpsi=var(repsi);
%i=50; qqplot((repsi(:,i)-hatEpsi(i))/sqrt(SEpsi(i)));
hatCalpha=mean(rem);
SDm=std(rem);



if sigma_star<=1  
    distribution='N(0,1)';
elseif sigma_star==41
    distribution='t(4)';
elseif sigma_star==22
    distribution='Schi^2(2)';
end
disp(['Power analysis with ','epsilon_i~',distribution]);
disp(array2table([n,nu,tilde_alpha(1),hatCalpha],'VariableNames',{'n','nu','tilde_alpha','power'}))

