function [beta_hat,gamma_hat,hatf_fun,coefficients]=est_PR(X,Z,Y,degree,beta0,gamma0)
% MATLAB script for local quasi-likelihood estimation in a generalized single index model


X1=X(:,1);
X2=X(:,2:end);



k=1;err=1;
rerr=[];

while err>1e-3 && k<150
    
    
    coefficients = polyfit(X*[1;beta0], Y-Z*gamma0, degree);
    
    
    
    hatf_fun=@(x) polyval(coefficients, x);
    
    options=optimoptions(@fminunc,'Display','off');
    global_loss_beta = @(beta) ...
        sum((Y - Z * gamma0-(hatf_fun(X1+X2*beta))).^2);
    beta_hat=fminunc(@(beta) global_loss_beta(beta), beta0, options);
    
    global_loss_gamma = @(gamma) ...
        sum((Y - Z * gamma-(hatf_fun(X1+X2*beta_hat))).^2);
    
    if isempty(Z)
        gamma_hat=reshape([], 0, 1);
    else
        gamma_hat = fminunc(@(gamma) global_loss_gamma(gamma), gamma0, options);
    end
    
    
    
    err=norm([beta_hat;gamma_hat]-[beta0;gamma0]);
    rerr(k,:)=[err,beta_hat',gamma_hat'];
    k=k+1;
    beta0=beta_hat;
    gamma0=gamma_hat;
end