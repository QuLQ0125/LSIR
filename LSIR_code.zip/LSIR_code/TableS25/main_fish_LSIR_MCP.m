clc;clear;close all
%%%---fish_LSIR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];%removing a extreme data point
example=4;
XIC=[1,2,3,6];
ZXI=[1:6];
variable_names={'CIC0','SM1\_Dz(Z)',' GATS1i','NdsCH','NdssC','MLOGP '};

SCXI=[1,2,6];%[1,2;1,3;1,6;2,3;2,6;3,6], [1,2,3;1,2,6;1,3,6;2,3,6], [1,2,3,6] can be selected.
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
SDXI=ZXI(~ismember(ZXI,SCXI));
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
d1=size(X,2);
d2=size(Z,2);
tildeZ=[ones(n,1),Z];

vecMn=[3,5,7,10];
for i_Mn=1:length(vecMn)
    Mn=vecMn(i_Mn);
    
    nu=0.7;
    c1=1;
    deltan=c1*(log(Mn+1)/n)^(nu);
    B=5;
    cn=log(log(n));
    maxiter=1000;
    tol=1e-4;
    
    [beta_hat,gamma_hat]=est_PR_global(X,Z,y,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
    Beta0wan1=beta_hat;
    Gamma0wan1=gamma_hat;
    Eta0wan1=[0;Gamma0wan1];
    Alpha0wan1=zeros(Mn+1,1);
    %plot(X(:,1)+X(:,2:end)*Beta0wan1,y-Z*Gamma0wan1,'.')
    Tau0wan1=linspace(min(X(:,1)+X(:,2:end)*Beta0wan1),max(X(:,1)+X(:,2:end)*Beta0wan1),Mn+2)';
    Tau0wan1=Tau0wan1(2:end-1);
    
    % pen='SCAD';t=3.7;
    pen='MCP';t=3;
    
    lambdamax=0.3;numlambda=100;
    Lambdawan=[linspace(0,lambdamax*0.7,numlambda*0.9),linspace(lambdamax*0.7,lambdamax,numlambda*0.1),3];
    % Lambdawan=Lambdawan(end:-1:1);
    ifplot='false';
    disp(['group: variables LC50 as y, ','variables ',strjoin(variable_names(SCXI),', '),' as X and ','variables ',strjoin(variable_names(SDXI),', '),' as Z'])
    results_LSIR=est_LSIR(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambdawan,t,deltan,cn,pen,maxiter,tol,B,ifplot);
    
    
    save(['Mn-',num2str(Mn),'fish_LSIR_est_MCP.mat'])
end