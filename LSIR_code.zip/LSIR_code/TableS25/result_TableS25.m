vecMn=[3,5,7,10];
result_TableS25_SCAD=[];
for i_Mn1=1:length(vecMn)
    Mn=vecMn(i_Mn1);
    load(['Mn-',num2str(Mn),'fish_LSIR_est_SCAD.mat']);
    result_TableS25_SCAD(i_Mn1,1)=results_LSIR.hateta(1);
    result_TableS25_SCAD(i_Mn1,[2,3,4])=results_LSIR.hatalpha;
    result_TableS25_SCAD(i_Mn1,[5,6])=results_LSIR.hattau;
    result_TableS25_SCAD(i_Mn1,[7,8])=results_LSIR.hatbeta(2:end);
    result_TableS25_SCAD(i_Mn1,[9,10,11])=results_LSIR.hateta(2:end);
    result_TableS25_SCAD(i_Mn1,13)=results_LSIR.R2;
    load(['Mn-',num2str(Mn),'fish_LSIR_est_SCAD_cv.mat']);
    result_TableS25_SCAD(i_Mn1,12)=PE;
end


result_TableS25_MCP=[];
for i_Mn1=1:length(vecMn)
    Mn=vecMn(i_Mn1);
    load(['Mn-',num2str(Mn),'fish_LSIR_est_MCP.mat']);
    result_TableS25_MCP(i_Mn1,1)=results_LSIR.hateta(1);
    result_TableS25_MCP(i_Mn1,[2,3,4])=results_LSIR.hatalpha;
    result_TableS25_MCP(i_Mn1,[5,6])=results_LSIR.hattau;
    result_TableS25_MCP(i_Mn1,[7,8])=results_LSIR.hatbeta(2:end);
    result_TableS25_MCP(i_Mn1,[9,10,11])=results_LSIR.hateta(2:end);
    result_TableS25_MCP(i_Mn1,13)=results_LSIR.R2;
    load(['Mn-',num2str(Mn),'fish_LSIR_est_MCP_cv.mat']);
    result_TableS25_MCP(i_Mn1,12)=PE;
end

result_TableS25_PLSIR=[];
load('fish_PLSIR_est_cv.mat')
result_TableS25_PLSIR(:,[7,8])=hatBeta1';
result_TableS25_PLSIR(:,[9,10,11])=hatGamma1';
result_TableS25_PLSIR(:,12)=PE;
result_TableS25_PLSIR(:,13)=R2_train;


result_TableS25_LR=[];
load('fish_LR_est_cv.mat')
result_TableS25_LR(:,1)=hatgamma0;
result_TableS25_LR(:,2)=hatalpha0;
result_TableS25_LR(:,[7,8])=hatBeta1';
result_TableS25_LR(:,[9,10,11])=hatGamma1';
result_TableS25_LR(:,12)=PE;
result_TableS25_LR(:,13)=R2_LR_train;

TableS25=[result_TableS25_SCAD;result_TableS25_MCP;result_TableS25_LR;result_TableS25_PLSIR];

row_labels={'SCAD-Mn3','SCAD-Mn5','SCAD-Mn7','SCAD-Mn10',...
           'MCP-Mn3','MCP-Mn5','MCP-Mn7','MCP-Mn10',...
           'LR','PLSIR'};
col_labels={'gamma0','alpha0','alpha1','alpha2','tau1','tau2','beta2','beta3','gamma1','gamma2','gamma3','PE','R^2'};
TableS25_tabletype = array2table(TableS25, ...
    'VariableNames',col_labels,'RowNames', row_labels)