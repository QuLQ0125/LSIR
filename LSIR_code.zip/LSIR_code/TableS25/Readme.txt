This is the Matlab code for Table S25.


The matlab codes:

main_fish_LSIR_SCAD.m: This file is used to calculate the estimated values of the LSIR model and the value of R^2 on the fish toxicity dataset, where the penalty function is SCAD.

main_fish_LSIR_SCAD_cv.m: This file is used to calculate the value of PE on the fish toxicity dataset, where the penalty function is SCAD.

main_fish_LSIR_MCP.m: This file is used to calculate the estimated values of the LSIR model and the value of R^2 on the fish toxicity dataset, where the penalty function is MCP.

main_fish_LSIR_MCP_cv.m: This file is used to calculate the value of PE on the fish toxicity dataset, where the penalty function is MCP.

main_fish_PLSIR_cv.m: This file is used to calculate the estimated values of the PLSIR model and the values of PE and R^2 on the fish toxicity dataset.

main_fish_LR_cv.m: This file is used to calculate the estimated values of the LR model and the values of PE and R^2 on the fish toxicity dataset.

result_TableS25.m: This file is used to obtain Table S25.


You can directly carry out the code: main_TableS25.m.


