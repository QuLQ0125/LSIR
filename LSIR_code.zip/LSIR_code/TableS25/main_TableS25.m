clc;clear;close all
main_fish_LSIR_SCAD

main_fish_LSIR_SCAD_cv

main_fish_LSIR_MCP

main_fish_LSIR_MCP_cv

main_fish_LR_cv

main_fish_PLSIR_cv

clc
result_TableS25