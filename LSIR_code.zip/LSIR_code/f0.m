function Q=f0(T,tau)

Q=(T-tau).*(T>tau);