function [Alpha1,Tauwan,Beta1,Eta1,e]=est_ADMM(Z,X,y,Mn,D,A,Alpha0wan1,Beta0wan1,Eta0wan1,Tau0wan1,lambda,t,deltan,fun,maxiter,tol)
%%%---ADMM algorithm---%%%
opts1 = optimoptions('fmincon','MaxIterations',100,'StepTolerance',10^(-4),'Display','off','Algorithm', 'sqp');
n=size(X,1);
d1=size(X,2);
tildeZ=[ones(n,1),Z];
d2=size(Z,2);

IMn1=eye(Mn+1,Mn+1);
IMn1(1,1)=0;

Beta0=Beta0wan1;
Eta0=Eta0wan1;
Tau0=Tau0wan1;
Alpha0=Alpha0wan1;
Zeta0=Alpha0(2:end);
V0=zeros(Mn,1);
err=inf;
e=1;

while err>tol && e<maxiter
    
    Q0=[];
    T0=(X(:,1)+X(:,2:end)*Beta0);
    Q0=[T0,qn(T0,Tau0',deltan)];
    vartheta=1;
    Alpha00=Alpha0;Eta00=Eta0;err1=inf;e1=1;
    while err1>1e-4 && e1<=100
        Alpha1=(Q0'*Q0+n*vartheta*IMn1)\(Q0'*(y-tildeZ*Eta00)+n*vartheta*([0;Zeta0]-[0;V0]/vartheta));
        Eta1=(tildeZ'*tildeZ)\(tildeZ'*(y-Q0*Alpha1));
        u1=Alpha1(2:end)+V0/vartheta;
        Zeta1=[];
        Zeta1=fun(u1,lambda,t,vartheta);
        V1=V0+vartheta*(Alpha1(2:end)-Zeta1);
        
        err1=norm([Alpha1;Eta1]-[Alpha00;Eta00]);
        Alpha00=Alpha1;
        Eta00=Eta1;
        V0=V1;
        Zeta0=Zeta1;
        e1=e1+1;
        
    end
    
    Alpha1(2:end)=Zeta1;
    objectiveTB=funTBZ(X,y,tildeZ,Alpha1,Eta1,deltan);
    rangeT=quantile(X(:,1)+X(:,2:end)*Beta0, 0.99)-quantile(X(:,1)+X(:,2:end)*Beta0, 0.01);
    TB1= fmincon(objectiveTB,[Tau0;Beta0],[A,zeros(Mn-1,length(Beta0))],-rangeT/30*ones(Mn-1,1),[],[],...
        [ones(Mn,1)*quantile(X(:,1)+X(:,2:end)*Beta0, 0.01);-ones(length(Beta0),1)*10],...
        [ones(Mn,1)*quantile(X(:,1)+X(:,2:end)*Beta0, 0.99);ones(length(Beta0),1)*10],[],opts1);%-4*deltan,fval, exitflag, output
    Tauwan=TB1(1:Mn,:);Beta1=TB1((Mn+1):end,:);
    
    
    Tau1=[];
    Tau1=D.*(abs(Zeta1)<=0)+Tauwan.*(abs(Zeta1)>0);%Tauwan;%
    
    err=norm([Alpha1;Beta1;Tau1;Eta1]-[Alpha0;Beta0;Tau0;Eta0]);
    
    Alpha0=Alpha1;
    Tau0=Tau1;
    Beta0=Beta1;
    
    Eta0=Eta1;
    e=e+1;
end
%  hatvarphi=@(w) Eta1(1)+[w,f0(w,Tau1')]*Alpha1;plot(X*[1;Beta1],y-Z*Eta1(2:end),'.',sort(X*[1;Beta1]),hatvarphi(sort(X*[1;Beta1])),'-','Linewidth',2)
