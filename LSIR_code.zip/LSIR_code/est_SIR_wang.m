function [hatbeta,hatgamma]=est_SIR_wang(X,Z,Y,beta0,gamma0,h)

[n,p1]=size(Z);
[n,p2]=size(X);
X1=X(:,1);
X2=X(:,2:end);

options=optimoptions(@fminunc,'Algorithm','quasi-newton','Display','off');
opts1 = optimoptions('fmincon','MaxIterations',100,'StepTolerance',10^(-5),'Display','off','Algorithm', 'sqp');%sqp
err=1;k=1;
hatgamma0=gamma0;%zeros(p1,1);
hatbeta0=beta0;
while err>1e-3 && k<=100
    hatY=Y-Z*hatgamma0;
%     plot(X*[1;beta0],Y-Z*gamma0,'.',sort(X*[1;beta0]),hatf_fun(sort(X*[1;beta0]),beta0,gamma0),'-')
    Obj=@(v) mean((hatY-hatf_fun_wang(X1+X2*v,v,hatgamma0,X,Z,Y,h)).^2);
    
    %hatbeta=fminunc(@(x) Obj(x),zeros(p2-1,1),options);

    hatbeta=fminunc(@(x) Obj(x),beta0,options);
%       hatbeta=fmincon(@(x) Obj(x), beta0, [], [], [], [], -6*ones(size(X2,2),1), 6*ones(size(X2,2),1), [], opts1);

%     hatbeta=hatbeta/norm(hatbeta);

    hatgamma=(Z'*Z)\(Z'*(Y-hatf_fun_wang(X1+X2*hatbeta,hatbeta,hatgamma0,X,Z,Y,h)));
    
    err=norm([hatbeta;hatgamma]-[hatbeta0;hatgamma0]);
    hatbeta0=hatbeta;
    hatgamma0=hatgamma;
    k=k+1;
end