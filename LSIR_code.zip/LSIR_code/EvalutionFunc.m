function Funcollect=EvalutionFunc
Funcollect.mySCAD=@mySCAD;
Funcollect.myMCP=@myMCP;
Funcollect.myST=@myST;

Funcollect.mydSCAD=@mydSCAD;%first derivative
Funcollect.mydMCP=@mydMCP;
Funcollect.mydST=@mydST;

Funcollect.myd2SCAD=@myd2SCAD;%second derivative
Funcollect.myd2MCP=@myd2MCP;
Funcollect.myd2ST=@myd2ST;
end

function f4=mySCAD(alpha,t,lambda)
f4=[];
f3=@(x) min(1,max(t-x/lambda,0)/(t-1));
for i=1:length(alpha)
    alphai=alpha(i);
    f4(i)=lambda*integral(f3,0,abs(alphai));
end
end


function f1=mydSCAD(alpha,t,lambda)
f1=lambda*sign(alpha).*(abs(alpha)<=lambda)+...
    (t*lambda-abs(alpha))/(t-1).*sign(alpha).*(abs(alpha)>lambda & abs(alpha)<=(t*lambda))+...
    0.*(abs(alpha)>(t*lambda));
end

function f2=myd2SCAD(alpha,t,lambda)
f2=-1/(t-1).*sign(alpha).*(abs(alpha)>lambda & abs(alpha)<=(t*lambda));
end

function f1=mydMCP(alpha,t,lambda)
f1=(lambda-abs(alpha)/t).*sign(alpha).*(abs(alpha)<=(t*lambda));
end

function f2=myd2MCP(alpha,t,lambda)
f2=-1/t.*sign(alpha).*(abs(alpha)<=(t*lambda));
end

function f4=myMCP(alpha,t,lambda)
f4=[];
f3=@(x) max(1-x/(t*lambda),0);
for i=1:length(alpha)
    alphai=alpha(i);
    f4(i)=lambda*integral(f3,0,abs(alphai));
end
end



function f1=mydST(alpha,~,lambda)
f1=lambda.*sign(alpha);
end



function f2=myd2ST(alpha,t,lambda)
f2=0;
end


function f4=myST(alpha,t,lambda)
f4=lambda*abs(alpha);
end