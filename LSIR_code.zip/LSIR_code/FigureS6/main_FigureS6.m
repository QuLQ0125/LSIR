clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

figure('Position', [200, 200, 1500,500]);
T1=-2:0.0001:2;
T1=T1';
Q1=[T1,f0(T1,0')];
y11=Q1*[-1;1.5];
desired_xticks=[-6:1:6];
desired_yticks =[-10:0.5:10];
subplot(1,3,1)
rectangle('Position', [0, 0, 1, 1], 'Curvature', [1, 1]);
axis square;
plot(T1,y11,'k-','linewidth',2)
set(gca,'FontSize',22,'Fontname', 'Times New Roman')
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
xticks(desired_xticks);
ylabel('$\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
yticks(desired_yticks);
title('Case 1','Fontsize',24,'Fontname','Times New Roman')
set(gca, 'Position', [0.0625, 0.15, 0.25, 0.7]);


subplot(1,3,2)
T2=-3:0.0001:3;
T2=T2';
Q2=[T2,f0(T2,[-1;1]')];
y21=Q2*[1;-2;2];

axis square;
rectangle('Position', [0, 0, 1, 1], 'Curvature', [1, 1]);
plot(T2,y21,'k-','linewidth',2)
xlim([-3,3])
set(gca,'FontSize',22,'Fontname', 'Times New Roman')
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
desired_xticks21=[-3:1:3];
xticks(desired_xticks21);
ylabel('$\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
yticks(desired_yticks);
title('Case 2','Fontsize',24,'Fontname','Times New Roman')
set(gca, 'Position', [0.385, 0.15, 0.25, 0.7]);


subplot(1,3,3)
T4=-6:0.0001:6;
T4=T4';
Q4=[];
Q4=[T4,f0(T4,[-4;-2;2;4]')];
y43=Q4*[-1;3;-2;-2;3];
axis square;
rectangle('Position', [0, 0, 1, 1], 'Curvature', [1, 1]);
plot(T4,y43,'k-','linewidth',2)
ylim([4,9]);
set(gca,'FontSize',22,'Fontname', 'Times New Roman')
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
desired_xticks43=[-6:2:6];
desired_yticks43 =[-10:1:10];
xticks(desired_xticks43);
ylabel('$\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
yticks(desired_yticks43);
title('Case 3','Fontsize',24,'Fontname','Times New Roman')
set(gca, 'Position', [0.6875, 0.15, 0.25, 0.7]);