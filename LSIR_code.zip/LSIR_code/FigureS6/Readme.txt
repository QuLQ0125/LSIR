This is the Matlab code for Figure S6.

You can directly carry out the code: main_FigureS6.m.