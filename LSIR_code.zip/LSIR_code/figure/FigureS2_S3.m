clc;clear;
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

figure
t = tiledlayout(2, 2, 'TileSpacing', 'loose', 'Padding', 'loose');
nexttile
data=[0.017 	0.016 	0.016 	0.026 	0.025 	0.065 	0.198 	0.340 
1.027 	1.025 	1.025 	1.026 	1.025 	1.025 	1.084 	1.254 
0.006 	0.006 	0.005 	0.006 	0.006 	0.005 	0.050 	0.123 
1.007 	1.007 	1.008 	1.007 	1.007 	1.008 	1.017 	1.232 
0.004 	0.003 	0.004 	0.004 	0.003 	0.004 	0.027 	0.052 
0.996 	0.996 	0.997 	0.996 	0.997 	0.997 	1.005 	1.228 
];
bias_index=[1,3,5];
Mn3SCAD_bias=data(bias_index,1);
Mn7SCAD_bias=data(bias_index,2);
Mn10SCAD_bias=data(bias_index,3);
Mn3MCP_bias=data(bias_index,4);
Mn7MCP_bias=data(bias_index,5);
Mn10MCP_bias=data(bias_index,6);
LSIR_bias=data(bias_index,7);
LR_bias=data(bias_index,8);
n=[1,2,3];

PE_index=[2,4,6];
Mn3SCAD_PE=data(PE_index,1);
Mn7SCAD_PE=data(PE_index,2);
Mn10SCAD_PE=data(PE_index,3);
Mn3MCP_PE=data(PE_index,4);
Mn7MCP_PE=data(PE_index,5);
Mn10MCP_PE=data(PE_index,6);
LSIR_PE=data(PE_index,7);
LR_PE=data(PE_index,8);


plot(n,Mn3SCAD_bias*100,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_bias*100,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_bias*100,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias*100,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias*100,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(a) Estimation error with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[0:0.1:0.4]*100;
yticks(desired_yticks);
xticklabels({'100','500','1000'});

nexttile
plot(n,Mn3SCAD_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(b) PE with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[1:0.1:1.3];
yticks(desired_yticks);
xticklabels({'100','500','1000'});
ylim([0.99,1.3])



nexttile
plot(n,Mn3MCP_bias*100,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_bias*100,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_bias*100,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias*100,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias*100,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(c) Estimation error with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[0:0.1:0.4]*100;
yticks(desired_yticks);
xticklabels({'100','500','1000'});

nexttile
plot(n,Mn3MCP_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(d) PE with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[1:0.1:1.3];
yticks(desired_yticks);
xticklabels({'100','500','1000'});
ylim([0.99,1.3])


set(legend,'interpreter','latex','Fontsize',24,'Fontname','Times New Roman',...
    'LineWidth',0.75,'Orientation', 'horizontal')

lgd=legend();
lgd.Layout.Tile = 'south';





figure
t = tiledlayout(2, 2, 'TileSpacing', 'loose', 'Padding', 'loose');



data=[0.094 	0.009 	0.021 	0.080 	0.075 	0.073 	0.370 	0.754 
1.057 	1.059 	1.058 	1.058 	1.057 	1.057 	1.085 	1.217 
0.002 	0.003 	0.003 	0.003 	0.003 	0.003 	0.047 	0.684 
1.004 	1.003 	1.004 	1.004 	1.003 	1.003 	1.018 	1.193 
0.001 	0.001 	0.001 	0.001 	0.001 	0.001 	0.026 	0.676 
0.999 	0.999 	0.999 	0.999 	0.999 	0.999 	1.010 	1.182 
];
bias_index=[1,3,5];
Mn3SCAD_bias=data(bias_index,1);
Mn7SCAD_bias=data(bias_index,2);
Mn10SCAD_bias=data(bias_index,3);
Mn3MCP_bias=data(bias_index,4);
Mn7MCP_bias=data(bias_index,5);
Mn10MCP_bias=data(bias_index,6);
LSIR_bias=data(bias_index,7);
LR_bias=data(bias_index,8);
n=[1,2,3];

PE_index=[2,4,6];
Mn3SCAD_PE=data(PE_index,1);
Mn7SCAD_PE=data(PE_index,2);
Mn10SCAD_PE=data(PE_index,3);
Mn3MCP_PE=data(PE_index,4);
Mn7MCP_PE=data(PE_index,5);
Mn10MCP_PE=data(PE_index,6);
LSIR_PE=data(PE_index,7);
LR_PE=data(PE_index,8);

nexttile
plot(n,Mn3SCAD_bias*100,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_bias*100,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_bias*100,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias*100,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias*100,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(a) Estimation error with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[0:0.2:0.8]*100;
yticks(desired_yticks);
xticklabels({'100','500','1000'});

nexttile
plot(n,Mn3SCAD_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7SCAD_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10SCAD_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(b) PE with SCAD','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[0.95:0.05:1.25];
yticks(desired_yticks);
xticklabels({'100','500','1000'});
ylim([0.99,1.25])


nexttile
plot(n,Mn3MCP_bias*100,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_bias*100,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_bias*100,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_bias*100,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','$PLSIR$','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_bias*100,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','$LR$','Color',[0.47,0.67,0.19])
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(c) Estimation error with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('Estimation error','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[0:0.2:0.8]*100;
yticks(desired_yticks);
xticklabels({'100','500','1000'});


nexttile
plot(n,Mn3MCP_PE,'-','Linewidth',3, 'Marker','^','MarkerSize',15,'DisplayName','$M_n=3$','Color',[108 168 175]/255)
hold on;plot(n,Mn7MCP_PE,'-','Linewidth',3, 'Marker','d','MarkerSize',15,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,Mn10MCP_PE,'-','Linewidth',3, 'Marker','o','MarkerSize',15,'DisplayName','$M_n=10$','Color',[223 122 094]/255)
hold on;plot(n,LSIR_PE,'-','Linewidth',3, 'Marker','s','MarkerSize',15,'DisplayName','PLSIR','Color',[0.93,0.69,0.13])
hold on;plot(n,LR_PE,'-','Linewidth',3, 'Marker','*','MarkerSize',15,'DisplayName','LR','Color',[0.47,0.67,0.19])


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(d) PE with MCP','Fontsize',24,'Fontname','Times New Roman')
xlabel('$n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('PE','Fontsize',24,'Fontname','Times New Roman');
box on;
desired_xticks=[1:3];
xticks(desired_xticks);
desired_yticks =[1:0.05:1.25];
yticks(desired_yticks);
xticklabels({'100','500','1000'});
ylim([0.99,1.25])


set(legend,'interpreter','latex','Fontsize',24,'Fontname','Times New Roman',...
    'LineWidth',0.75,'Orientation', 'horizontal')

lgd=legend();
lgd.Layout.Tile = 'south';