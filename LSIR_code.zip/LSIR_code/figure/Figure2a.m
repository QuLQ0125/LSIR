clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];

figure('Position', [200, 200, 800,600]);


hatBeta11=[1.0000;0.0633];
hatEta1=[28.1880;-2.7726;1.9524];
hatTau1=-0.1490;
hatAlpha1=[3.1827;19.8464];
LhatTau1=-0.3715;
UhatTau1=0.0736;

T0=X*hatBeta11;
T1=sort(T0);
Q1=[T1,f0(T1,hatTau1')];
hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
if isempty(Z)
    y2=y;
else
    y2=y-Z*hatEta1(2:end);
end
plt=[];
hold on
plot(T0,y2,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);


for l=1:length(hatTau1)
    hold on
    plot([hatTau1(l),hatTau1(l)],[-20,120],'--','linewidth',2,'Color',[0 0 0])
    plot([LhatTau1(l),LhatTau1(l)],[-20,120],'-','linewidth',1.2,'Color',[0 0 0])
    plot([UhatTau1(l),UhatTau1(l)],[-20,120],'-','linewidth',1.2,'Color',[0 0 0])
    fill([LhatTau1(l),UhatTau1(l),UhatTau1(l),LhatTau1(l)],[-20,-20,120,120],[0.65 0.65 0.65],'FaceAlpha',0.3);
end
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(a) Real estate valuation dataset','Fontsize',24,'Fontname','Times New Roman')
xlabel('${X}_i^\top\widehat{\beta}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-{Z}_i^\top{\widehat\gamma}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-5:1:2];
desired_yticks =[-100:20:140];
xticks(desired_xticks);
yticks(desired_yticks);
ylim([-20,120])
xlim([-5,2])
w=[-4.5:0.01:1.22]';
y_LSIR=hatvarphi(w);


hatGamma1=[-2.8992;1.6301];
hatBeta1wan=[6.9580;3.7053];
hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
hatalpha0=hatBeta1wan(1);
u=sort(X*[1;hatBeta1]);
hatgamma0=37.9802;
hatf_fun=@(w) hatgamma0+hatalpha0*w;
y_MLR=hatf_fun(w);




hatBeta1=0.1156;
hatGamma1=[-2.9747;1.8841];
h=0.3;
y_SIR=hatf_fun_wang(w,hatBeta1,hatGamma1,X,Z,y,h);



hold on;
plt(1)=plot(w,y_MLR,'--','Linewidth',4,'DisplayName','LR','Color',[0.49,0.18,0.56]);
hold on;plt(2)=plot(w,y_SIR,'-.','Linewidth',4,'DisplayName','PLSIR','Color',[0.93,0.69,0.13]);
hold on;plt(3)=plot(w,y_LSIR,'-','Linewidth',4,'DisplayName','LSIR','Color',[1,0,0]);

legend(plt,'Location','NorthWest','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman')



