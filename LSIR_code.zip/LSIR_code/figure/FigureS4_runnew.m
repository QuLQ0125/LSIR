clc;clear
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);
addpath([parentFolder,'\simulation']);

t = tiledlayout(1, 2, 'TileSpacing', 'loose', 'Padding', 'loose');


%%%---Case S2---%%%
nexttile; 

%%%---LSIR---%%%
[example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=CaseS2();%Case 1-Case 3 and Case S1-Case S3

%%%---input---%%%
n1=100;%the replications times
n=1250;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set
sigma_star=1;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)
Mn=10;%the number of knots to be selected, Mn=3 5 7 10
nu=0.7;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
c1=1;%$\delta_n=c1*(log(Mn+1)/n)^nu$
B=2;%the bootstrap sampling times



%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);
deltan=c1*(log(Mn+1)/n)^(nu);
cn=[1,log(log(n))];
pen='SCAD';
lambdamax=0.2;numlambda=10;
Lambdawan=[linspace(0,lambdamax*0.1,numlambda*0.9),linspace(lambdamax*0.15,lambdamax,numlambda*0.1),3];%
t=3.7;

rehatTheta111=Simulation_SCAD_MCP_figure(Mn,Lambdawan,t,deltan,cn,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B);


w=[-3:0.01:3]';
hat_varphi_LSIR=[];
hat_varphi_LSIR_iter=[];
for iter=1:n1
k=2;
hatAlpha1=rehatTheta111(iter,1:Mn+1,k)';
hatTau1=rehatTheta111(iter,(Mn+1+1):(2*Mn+1),k)';
hatBeta11=[1;rehatTheta111(iter,(2*Mn+1+1):(2*Mn+d1),k)'];
hatEta1=rehatTheta111(iter,(2*Mn+d1+1):(2*Mn+d1+d2+1),k)';
hat_varphi_iter=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
hat_varphi_LSIR_iter(:,iter)=hat_varphi_iter(w);
hold on;plot(w,hat_varphi_iter(w),'Color', [0.7, 0.7, 0.7])
end
hat_varphi_LSIR=mean(hat_varphi_LSIR_iter,2);



%%%---SIR-wang---%%%
pen='PLSIR';
[rehatTheta1,reh]=Simulation_PLSIR_figure(pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type);




hat_varphi_SIR_wang_iter=[];
for iter=1:n1
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    hat_varphi_SIR_wang_iter(:,iter)=hatf_fun_wang(w,rehatTheta1(iter,1),rehatTheta1(iter,2),X_train,Z_train,y_train,reh(iter));
end
hat_varphi_SIR_wang=mean(hat_varphi_SIR_wang_iter,2);

plt=[];
plt(1)=plot(w,varphi(w),'--','linewidth',7,'Color',[60 64 91]/255);
hold on;plt(2)=plot(w,hat_varphi_SIR_wang,'-.','linewidth',5,'Color',[108 168 175]/255);
hold on;plt(3)=plot(w,hat_varphi_LSIR,'-','linewidth',5,'Color',[223 122 094]/255);

legend(plt,'True','PLSIR','LSIR','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman','Location','NorthWest')
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$\widehat\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
title('(a)','Fontsize',24,'Fontname','Times New Roman')
desired_yticks =[-3:1:4];
desired_xticks =[-4:1:4];
xticks(desired_xticks )
yticks(desired_yticks);
ylim([-1,4])
xlim([-3,3])
box on





%%%---Case S3---%%%
nexttile; 
w=[-3:0.1:3]';

%%%---LSIR---%%%
[example,d2,d1,meanZ,meanX,sigmaZ,sigmaX,...
    Eta_star,Beta_star,Alpha_star,Tau_star,Mn_star,sn_star,D,Theta_o_star,varphi,varphi_type]=CaseS3();%Case 1-Case 3 and Case S1-Case S3

%%%---input---%%%
n1=100;%the replications times
n=1250;%sample size, 0.8*n as sample size of train set, and 0.2*n as sample size of test set
sigma_star=1;%sigma_star<=1 denotes N(0,sigma_star^2), sigma_star=22 denotes Schi^2(2);sigma_star=41 denotes t(4)
Mn=10;%the number of knots to be selected, Mn=3 5 7 10
nu=0.7;%the order of delta_n, $\delta_n=c1*(log(Mn+1)/n)^nu$, nu=0.6 0.7 0.8
c1=1;%$\delta_n=c1*(log(Mn+1)/n)^nu$
B=2;%the bootstrap sampling times



%%%---output---%%%
[n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Eta_star,Beta_star,Alpha_star,Tau_star,n1,varphi);
deltan=c1*(log(Mn+1)/n)^(nu);
cn=[1,log(log(n))];
pen='SCAD';
lambdamax=0.2;numlambda=10;
Lambdawan=[linspace(0,lambdamax*0.1,numlambda*0.9),linspace(lambdamax*0.15,lambdamax,numlambda*0.1),3];%
t=3.7;

rehatTheta111=Simulation_SCAD_MCP_figure(Mn,Lambdawan,t,deltan,cn,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B);


hat_varphi_LSIR_iter=[];
hat_varphi_LSIR=[];
for iter=1:n1
k=2;
hatAlpha1=rehatTheta111(iter,1:Mn+1,k)';
hatTau1=rehatTheta111(iter,(Mn+1+1):(2*Mn+1),k)';
hatBeta11=[1;rehatTheta111(iter,(2*Mn+1+1):(2*Mn+d1),k)'];
hatEta1=rehatTheta111(iter,(2*Mn+d1+1):(2*Mn+d1+d2+1),k)';
hat_varphi_iter=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
hat_varphi_LSIR_iter(:,iter)=hat_varphi_iter(w);
hold on;plot(w,hat_varphi_iter(w),'Color', [0.7, 0.7, 0.7])
end
hat_varphi_LSIR=mean(hat_varphi_LSIR_iter,2);

%%%---SIR-wang---%%%
pen='PLSIR';
[rehatTheta1,reh]=Simulation_PLSIR_figure(pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type);
hat_varphi_SIR_wang_iter=[];
for iter=1:n1
    Z=n1Z(:,:,iter);
    X=n1X(:,:,iter);
    y=n1y(:,iter);
    numSamples = size(X, 1);
    rng(123);
    indices = randperm(numSamples);
    X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
    train_rate=0.8;
    X_train=X(1:ceil(train_rate*numSamples),:);
    Z_train=Z(1:ceil(train_rate*numSamples),:);
    y_train=y(1:ceil(train_rate*numSamples),:);
    hat_varphi_SIR_wang_iter(:,iter)=hatf_fun_wang(w,rehatTheta1(iter,1),rehatTheta1(iter,2),X_train,Z_train,y_train,reh(iter));

end
hat_varphi_SIR_wang=mean(hat_varphi_SIR_wang_iter,2);
plt=[];
hold on;plt(1)=plot(w,varphi(w),'k--','linewidth',7,'Color',[60 64 91]/255);
hold on;plt(2)=plot(w,hat_varphi_SIR_wang,'-.','linewidth',5,'Color',[108 168 175]/255);
hold on;plt(3)=plot(w,hat_varphi_LSIR,'-','linewidth',5,'Color',[223 122 094]/255);


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman');
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$\widehat\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
title('(b)','Fontsize',24,'Fontname','Times New Roman')
desired_yticks =[-5:1:5];
desired_xticks =[-4:1:4];
xlim([-3,3])
box on
legend(plt,'True','PLSIR','LSIR','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman','Location','NorthWest')


