clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

figure('Position', [200, 200, 800,600]);
redata1=csvread('qsar_fish_toxicity.csv');

redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
redata1(373,:)=[];%extreme data point
XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
d1=size(X,2);
d2=size(Z,2);
tildeZ=[ones(n,1),Z];

hatBeta11=[1.0000;1.32;1.22];
hatEta1=[2.01;-0.37;0.38;0.03];
hatTau1=[-2.77;4.98];
hatAlpha1=[-0.20;0.69;-0.94];
LhatTau1=[-3.52;3.97];
UhatTau1=[-2.03;6.00];

T0=X*hatBeta11;
T1=[min(T0)-0.5;sort(T0);max(T0)+0.5];
Q1=[T1,f0(T1,hatTau1')];
hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
if isempty(Z)
    y2=y;
else
    y2=y-Z*hatEta1(2:end);
end
plt=[];
hold on

plt(1)=plot(T0,y2,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);
hold on
plt(2)=plot(T1,hatvarphi(T1),'-','linewidth',4,'Color',[1 0 0]);

for l=1:length(hatTau1)
    hold on
    plot([hatTau1(l),hatTau1(l)],[0,10],'--','linewidth',2,'Color',[0 0 0])
    plot([LhatTau1(l),LhatTau1(l)],[0,10],'-','linewidth',1.2,'Color',[0 0 0])
    plot([UhatTau1(l),UhatTau1(l)],[0,10],'-','linewidth',1.2,'Color',[0 0 0])
    fill([LhatTau1(l),UhatTau1(l),UhatTau1(l),LhatTau1(l)],[0,0,10,10],[0.65 0.65 0.65],'FaceAlpha',0.3);
end
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('${X}_i^\top\widehat{\beta}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-{Z}_i^\top{\widehat\gamma}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:2:100];
desired_yticks =[-100:2:100];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([-8,8])
ylim([0,10])