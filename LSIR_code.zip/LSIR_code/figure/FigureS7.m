clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

t = tiledlayout(3, 3, 'TileSpacing', 'loose', 'Padding', 'loose');

%%%%%%%%%%%%%%%%%%%%%%%%%%%case 1
nexttile; 
data=[0.00694282	0.007594697	0.007161979
0.00663368	0.007757728	0.00732638
0.006357282	0.007773512	0.007180858
0.005098946	0.005340617	0.005306719
0.004843041	0.00532369	0.005324986
0.004655916	0.005281664	0.005101031
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)




set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')

ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(a) Case 1 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_yticks =[0:0.1:1];
desired_xticks =[0:2];
xticks(desired_xticks )
yticks(desired_yticks);
ylim([0.4,0.8])
xlim([-0.15,2.15])




nexttile; 
data=[0.006436507	0.005999225	0.006360782
0.0062247	0.005905001	0.006119735
0.006102249	0.005479979	0.006157606
0.001489961	0.001630474	0.001544934
0.001524065	0.001653957	0.001515455
0.001684802	0.001799207	0.001519335
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(b) Case 1 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0.1:0.2:0.7];
yticks(desired_yticks);
ylim([0.1,0.7])
xlim([-0.15,2.15])




nexttile; 
data=[0.008232847	0.010012395	0.009087675
0.007504717	0.009561671	0.008966278
0.007247489	0.009454146	0.008943348
0.002282362	0.002061994	0.002158119
0.002071744	0.001830266	0.002112407
0.002005606	0.00177766	0.002235801
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(c) Case 1 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0:0.3:2];
yticks(desired_yticks);
ylim([0,1.2])
xlim([-0.15,2.15])



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case 2
nexttile; 
data=[0.015407525	0.013058277	0.013744186
0.014949452	0.012351516	0.013066069
0.015265027	0.011943679	0.012067214
0.007933075	0.007787752	0.007266392
0.007947286	0.007489485	0.006987898
0.007892572	0.007081515	0.006610752
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(d) Case 2 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0.6:0.3:2];
yticks(desired_yticks);
ylim([0.6,1.8])
xlim([-0.15,2.15])



nexttile; 
data=[0.02690326	0.025862124	0.025610861
0.025931559	0.024690855	0.024986167
0.024972181	0.024804021	0.024059237
0.008816132	0.009098828	0.007870011
0.008500658	0.009123868	0.007504409
0.007999754	0.008664902	0.007123084
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(e) Case 2 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0.5:0.5:4];
yticks(desired_yticks);
ylim([0.5,3])
xlim([-0.15,2.15])




nexttile; 
data=[0.040602829	0.040839545	0.042663196
0.03914581	0.038815814	0.04212848
0.037843972	0.037319353	0.040222603
0.013838888	0.015396898	0.013375193
0.013562591	0.014774911	0.012702495
0.013164315	0.014088562	0.011942408
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(f) Case 2 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0:1:5];
yticks(desired_yticks);
ylim([1,5])
xlim([-0.15,2.15])




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case 3
nexttile; 
data=[0.033309847	0.031109488	0.030985042
0.030048721	0.028788656	0.030045251
0.028132411	0.029989074	0.030952645
0.012681443	0.008873451	0.009246324
0.012915123	0.009018218	0.009414673
0.01307143	0.009873677	0.01020672
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(g) Case 3 with $\epsilon_i\sim\mathcal{N}(0,1)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0.5:1:4];
yticks(desired_yticks);
ylim([0.5,3.5])
xlim([-0.15,2.15])



nexttile; 
data=[0.028657051	0.028070443	0.027393812
0.027291647	0.027239204	0.026959406
0.025836786	0.026952491	0.027106345
0.014046866	0.015684396	0.015924495
0.013212092	0.015485781	0.015704605
0.012660393	0.015673771	0.015844736
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(h) Case 3 with $\epsilon_i\sim$Schi$^2$(2)','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0:0.5:4];
yticks(desired_yticks);
ylim([1,3])
xlim([-0.15,2.15])




nexttile; 
data=[0.067625918	0.061953002	0.06444073
0.063924821	0.058248733	0.060403597
0.059273884	0.058041368	0.061862515
0.025557987	0.028753602	0.031020607
0.023032467	0.028443688	0.030578979
0.022185812	0.028670658	0.030377221
]*100;
n1000_06=data(1,:);n1000_07=data(2,:);n1000_08=data(3,:);
n2000_06=data(4,:);n2000_07=data(5,:);n2000_08=data(6,:);

n = [0,1,2]';
plot(n,n1000_06,'-','Linewidth',3, 'Marker','^','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_06,'-','Linewidth',3, 'Marker','x','MarkerSize',18,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n1000_08,'-','Linewidth',3, 'Marker','d','MarkerSize',14,'DisplayName','$M_n=3$','Color',[223 122 094]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','o','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_06,'-','Linewidth',3, 'Marker','v','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)
hold on;plot(n,n2000_08,'-','Linewidth',3, 'Marker','s','MarkerSize',14,'DisplayName','$M_n=7$','Color',[60 64 91]/255)

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
ylabel('$\|\widehat\theta_1-\theta_o^*\|$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman');
title('(i) Case 3 with $\epsilon_i\sim t(4)$','interpreter','latex','Fontsize',22,'Fontname','Times New Roman')
xticklabels({'Oracle','SCAD','MCP'});
desired_xticks =[0:2];
xticks(desired_xticks )
desired_yticks =[0:1:8];
yticks(desired_yticks);
ylim([2,7])
xlim([-0.15,2.15])




% % % Draw the legend
legendData = {'$(n,\nu)=(1000,0.6)$','$(n,\nu)=(1000,0.7)$','$(n,\nu)=(1000,0.8)$','$(n,\nu)=(2000,0.6)$','$(n,\nu)=(2000,0.7)$', '$(n,\nu)=(2000,0.8)$'};
legend(legendData )
set(legend,'interpreter','latex','Fontsize',22,'Fontname','Times New Roman',...
    'LineWidth',0.75,'Orientation', 'horizontal')

lgd=legend()
lgd.Layout.Tile = 'south';



