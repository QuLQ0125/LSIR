clc;clear;close all
figure('Position', [200, 200, 800,600]);

vectime_SCAD=[34.30 	38.45 	37.45 	49.15 	64.84 	65.59 	74.73 	84.19 	86.91 	106.35 	127.41 ];
vectime_MCP=[29.18 	33.60 	33.81 	43.92 	58.61 	56.20 	67.00 	78.30 	81.84 	94.26 	112.86 ];
vecMn=[5:15];
plot(vecMn,vectime_SCAD,'-','LineWidth',3,'Marker','o','Markersize',8,'Color',[0.00,0.45,0.74]);
hold on;plot(vecMn,vectime_MCP,'-','LineWidth',3,'Marker','.','Markersize',30,'Color',[0.85,0.33,0.10]);
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
legend('SCAD','MCP','Location','NorthWest','Fontname','Times New Roman','FontSize',24);
xlabel('$M_n$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('Computation time (seconds)','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
desired_xticks =[5:2:15];
xticks(desired_xticks )