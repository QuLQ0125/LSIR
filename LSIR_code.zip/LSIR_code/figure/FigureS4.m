clc;clear
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

t = tiledlayout(1, 2, 'TileSpacing', 'loose', 'Padding', 'loose');

%%%---Case S2---%%%
nexttile; 

%%%---LSIR---%%%
load('Case S2_LSIR.mat')
w=[-3:0.01:3]';
hat_varphi_LSIR=[];
hat_varphi_LSIR_iter=[];
for iter=1:n1
k=2;
hatAlpha1=rehatTheta111(iter,1:Mn+1,k)';
hatTau1=rehatTheta111(iter,(Mn+1+1):(2*Mn+1),k)';
hatBeta11=[1;rehatTheta111(iter,(2*Mn+1+1):(2*Mn+d1),k)'];
hatEta1=rehatTheta111(iter,(2*Mn+d1+1):(2*Mn+d1+d2+1),k)';
hat_varphi_iter=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
hat_varphi_LSIR_iter(:,iter)=hat_varphi_iter(w);
hold on;plot(w,hat_varphi_iter(w),'Color', [0.7, 0.7, 0.7])
end
hat_varphi_LSIR=mean(hat_varphi_LSIR_iter,2);

load('Case S2_PLSIR.mat')

%%%---SIR-wang---%%%
hat_varphi_SIR_wang=mean(hat_varphi_SIR_wang_iter,2);

plt=[];
plt(1)=plot(w,varphi(w),'--','linewidth',7,'Color',[60 64 91]/255);
hold on;plt(2)=plot(w,hat_varphi_SIR_wang,'-.','linewidth',5,'Color',[108 168 175]/255);
hold on;plt(3)=plot(w,hat_varphi_LSIR,'-','linewidth',5,'Color',[223 122 094]/255);

legend(plt,'True','PLSIR','LSIR','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman','Location','NorthWest')
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$\widehat\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
title('(a)','Fontsize',24,'Fontname','Times New Roman')
desired_yticks =[-3:1:4];
desired_xticks =[-4:1:4];
xticks(desired_xticks )
yticks(desired_yticks);
ylim([-1,4])
xlim([-3,3])
box on



%%%---Case S3---%%%
nexttile; 
w=[-3:0.1:3]';

%%%---LSIR---%%%
load('Case S3_LSIR.mat')
hat_varphi_LSIR_iter=[];
hat_varphi_LSIR=[];
for iter=1:n1
k=2;
hatAlpha1=rehatTheta111(iter,1:Mn+1,k)';
hatTau1=rehatTheta111(iter,(Mn+1+1):(2*Mn+1),k)';
hatBeta11=[1;rehatTheta111(iter,(2*Mn+1+1):(2*Mn+d1),k)'];
hatEta1=rehatTheta111(iter,(2*Mn+d1+1):(2*Mn+d1+d2+1),k)';
hat_varphi_iter=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
hat_varphi_LSIR_iter(:,iter)=hat_varphi_iter(w);
hold on;plot(w,hat_varphi_iter(w),'Color', [0.7, 0.7, 0.7])
end
hat_varphi_LSIR=mean(hat_varphi_LSIR_iter,2);

%%%---SIR-wang---%%%
load('Case S3_PLSIR.mat')
hat_varphi_SIR_wang=mean(hat_varphi_SIR_wang_iter,2);
plt=[];
hold on;plt(1)=plot(w,varphi(w),'k--','linewidth',7,'Color',[60 64 91]/255);
hold on;plt(2)=plot(w,hat_varphi_SIR_wang,'-.','linewidth',5,'Color',[108 168 175]/255);
hold on;plt(3)=plot(w,hat_varphi_LSIR,'-','linewidth',5,'Color',[223 122 094]/255);


set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman');
xlabel('$w$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
ylabel('$\widehat\varphi(w)$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman');
title('(b)','Fontsize',24,'Fontname','Times New Roman')
desired_yticks =[-5:1:5];
desired_xticks =[-4:1:4];
xlim([-3,3])
box on
legend(plt,'True','PLSIR','LSIR','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman','Location','NorthWest')


