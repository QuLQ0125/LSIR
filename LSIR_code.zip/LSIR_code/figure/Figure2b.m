clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];%
XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
d1=size(X,2);
d2=size(Z,2);
tildeZ=[ones(n,1),Z];

addpath(genpath('E:\lvlong11\realdata'))
figure('Position', [200, 200, 800,600]);

hatBeta11=[1.0000;1.23;1.11];
hatEta1=[2.31;-0.38;0.37;0.03];
hatTau1=[-2.38;4.73];
hatAlpha1=[-0.14;0.67;-1.24];
LhatTau1=[-3.02;3.91];
UhatTau1=[-1.75;5.54];

T0=X*hatBeta11;
T1=[min(T0)-0.5;sort(T0);max(T0)+0.5];
Q1=[T1,f0(T1,hatTau1')];
hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
if isempty(Z)
    y2=y;
else
    y2=y-Z*hatEta1(2:end);
end
plt=[];
hold on

plt(1)=plot(T0,y2,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);
hold on
plt(2)=plot(T1,hatvarphi(T1),'-','linewidth',4,'Color',[1 0 0]);

for l=1:length(hatTau1)
    hold on
    plot([hatTau1(l),hatTau1(l)],[0,10],'--','linewidth',2,'Color',[0 0 0])
    plot([LhatTau1(l),LhatTau1(l)],[0,10],'-','linewidth',1.2,'Color',[0 0 0])
    plot([UhatTau1(l),UhatTau1(l)],[0,10],'-','linewidth',1.2,'Color',[0 0 0])
    fill([LhatTau1(l),UhatTau1(l),UhatTau1(l),LhatTau1(l)],[0,0,10,10],[0.65 0.65 0.65],'FaceAlpha',0.3);
end
set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
title('(b) Fish toxicity dataset','Fontsize',24,'Fontname','Times New Roman')
xlabel('${X}_i^\top\widehat{\beta}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-{Z}_i^\top{\widehat\gamma}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:2:100];
desired_yticks =[-100:2:100];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([-8,10])
ylim([0,10])
w=[-6:0.01:9.5]';
y_LSIR=hatvarphi(w);



hatGamma1=[-0.2943;0.4136;0.0643];
hatBeta1wan=[0.2916;0.5380;0.5590];
hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
hatalpha0=hatBeta1wan(1);
u=sort(X*[1;hatBeta1]);
hatgamma0=3.9385;
hatf_fun=@(w) hatgamma0+hatalpha0*w;
y_MLR=hatf_fun(w);




hatBeta1=[1.3413;1.3115];
hatGamma1=[-0.3717;0.3703;0.0457];
h=0.9;
y_SIR=hatf_fun_wang(w,hatBeta1,hatGamma1,X,Z,y,h);

plt=[];
plt(1)=plot(w,y_MLR,'--','Linewidth',4,'DisplayName','LR','Color',[0.49,0.18,0.56]);
hold on;plt(2)=plot(w,y_SIR,'-.','Linewidth',4,'DisplayName','PLSIR','Color',[0.93,0.69,0.13]);
hold on;plt(3)=plot(w,y_LSIR,'-','Linewidth',4,'DisplayName','LSIR','Color',[1,0,0]);
legend(plt,'Location','NorthWest','LineWidth',0.75,'FontSize',24,'Fontname','Times New Roman')

