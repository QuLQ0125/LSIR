clc;clear;close all
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

t = tiledlayout(1, 2, 'TileSpacing', 'loose', 'Padding', 'loose');
example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];



nexttile
hatBeta11=[1.0000;0.0633];
hatEta1=[28.1880;-2.7726;1.9524];
hatTau1=-0.1490;
hatAlpha1=[3.1827;19.8464];
LhatTau1=-0.3715;
UhatTau1=0.0736;
hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
haty_LSIR=Z*hatEta1(2:end)+hatvarphi(X*hatBeta11);
hat_Epsilon_LSIR=y-haty_LSIR;
plot([10,60],[0,0],'k-','LineWidth',1.5)
hold on;
plot(haty_LSIR,hat_Epsilon_LSIR,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
title('(a) Real estate valuation dataset','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:10:100];
desired_yticks =[-40:20:80];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([10,60])
ylim([-40,80])


clc;clear;
redata1=csvread('qsar_fish_toxicity.csv');
redata1(:,1)=(redata1(:,1)-mean(redata1(:,1)))/std(redata1(:,1));
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,6)=(redata1(:,6)-mean(redata1(:,6)))/std(redata1(:,6));
% redata1(373,:)=[];
XIC=[1,2,3,6];
ZXI=[1:6];
SCXI=[1,2,6];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,7);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
d1=size(X,2);
d2=size(Z,2);
tildeZ=[ones(n,1),Z];

nexttile
hatBeta11=[1.0000;1.23;1.11];
hatEta1=[2.31;-0.38;0.37;0.03];
hatTau1=[-2.38;4.73];
hatAlpha1=[-0.14;0.67;-1.24];
LhatTau1=[-3.02;3.91];
UhatTau1=[-1.75;5.54];


hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
haty_LSIR=Z*hatEta1(2:end)+hatvarphi(X*hatBeta11);
hat_Epsilon_LSIR=y-haty_LSIR;
plot([1,8],[0,0],'k-','LineWidth',1.5)
hold on;
plot(haty_LSIR,hat_Epsilon_LSIR,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
title('(b) Fish toxicity dataset','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:1:100];
desired_yticks =[-6:3:6];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([1,8])
ylim([-6,6])

