clc;clear;close all
%%%---taipei_LR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


X_train=X;Z_train=Z;y_train=y;
XZ_train=[X_train,ones(size(X_train,1),1),Z_train];
bg=(XZ_train'*XZ_train)\(XZ_train'*y_train);

RMSE_LR_train=sqrt(mean((y_train-XZ_train*bg).^2));
ESS_LR_train=sum((y_train-XZ_train*bg).^2);
TSS_LR_train=sum((y_train-mean(y_train)).^2);
R2_LR_train=1-ESS_LR_train/TSS_LR_train;


hatGamma1=bg(size(X_train,2)+2:end);
hatBeta1wan=bg(1:size(X_train,2));
hatBeta1=hatBeta1wan(2:end)/hatBeta1wan(1);
hatalpha0=hatBeta1wan(1);

hatgamma0=bg(size(X_train,2)+1);


disp('Linear regression model (LR)')
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',R2_LR_train],'VariableNames',col_labels);
disp(PEtable)
save('taipei_LR_est')
