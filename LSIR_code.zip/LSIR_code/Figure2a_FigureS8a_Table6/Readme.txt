This is the Matlab code for Figure 2a, Table 6 and Figure S8a.

The matlab codes:

main_taipei_LR.m: This file is used to calculate the estimated values of the LR model on the real estate valuation dataset.

main_taipei_PLSIR.m: This file is used to calculate the estimated values of the PLSIR model on the real estate valuation dataset.

main_taipei_LSIR_SCAD.m: This file is used to calculate the estimated values of the LSIR model on the real estate valuation dataset, where the penalty function is SCAD.

main_taipei_LSIR_MCP.m: This file is used to calculate the estimated values of the LSIR model on the real estate valuation dataset, where the penalty function is MCP.

plot_figure2a.m: This file is used to draw Figure 2a.

result_Table6.m: This file is used to obtain Table 6.

plot_figureS8a.m: This file is used to draw Figure S8a.


You can directly carry out the code: main_Figure2a_Table6_FigureS8a.m.



