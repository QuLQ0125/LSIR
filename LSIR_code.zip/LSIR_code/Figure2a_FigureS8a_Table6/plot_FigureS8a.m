clc;clear;
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;
redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


figure('Position', [200, 200, 800,600]);

load('taipei_LSIR_est_SCAD.mat')
hatBeta11=results_LSIR.hatbeta;
hatEta1=results_LSIR.hateta;
hatTau1=results_LSIR.hattau;
hatAlpha1=results_LSIR.hatalpha;
LhatTau1=results_LSIR.CI(3,1);
UhatTau1=results_LSIR.CI(3,2);

hatvarphi=@(w) hatEta1(1)+[w,f0(w,hatTau1')]*hatAlpha1;
haty_LSIR=Z*hatEta1(2:end)+hatvarphi(X*hatBeta11);
hat_Epsilon_LSIR=y-haty_LSIR;
plot([10,60],[0,0],'k-','LineWidth',1.5)
hold on;
plot(haty_LSIR,hat_Epsilon_LSIR,'o','Markersize',6,'LineWidth',1,'Color',[0.0745098039215686 0.623529411764706 1]);

set(gca,'FontSize',22,'LineWidth',1,'Fontname','Times New Roman')
xlabel('$\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
ylabel('$Y_i-\widehat{Y_i}$','interpreter','latex','Fontsize',24,'Fontname','Times New Roman')
title('(a) Real estate valuation dataset','Fontsize',24,'Fontname','Times New Roman')
box on
desired_xticks=[-100:10:100];
desired_yticks =[-40:20:80];
xticks(desired_xticks);
yticks(desired_yticks);
xlim([10,60])
ylim([-40,80])