clc;clear;close all
%%%---taipei_PLSIR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);

example=3;
redata1=readmatrix('Real estate valuation data set.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


X_train=X;Z_train=Z;y_train=y;

h=0.3;
tic
[beta_hat,gamma_hat]=est_PR_global(X_train,Z_train,y_train,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
[hatBeta1,hatGamma1]=est_SIR_wang(X_train,Z_train,y_train,beta_hat,gamma_hat,h);
runtime=toc;
Ynew=y_train-Z_train*hatGamma1;
Xnew=X_train*[1;hatBeta1];
x=sort(Xnew);
hatYnew=hatf_fun_wang(Xnew,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
hatynew=hatf_fun_wang(x,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
RMSE_SIR_train=sqrt(mean((y_train-Z_train*hatGamma1-hatYnew).^2));
ESS_train=sum((y_train-hatYnew-Z_train*hatGamma1).^2);
TSS_train=sum((y_train-mean(y_train)).^2);
R2_train=1-ESS_train/TSS_train;


disp('Partially linear single index regression model (PLSIR)')
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',R2_train],'VariableNames',col_labels);
disp(PEtable)

save('taipei_PLSIR_est.mat')

