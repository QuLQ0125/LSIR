clc;clear;close all
main_taipei_LSIR_SCAD

main_taipei_LSIR_MCP

main_taipei_PLSIR

main_taipei_LR

clc
plot_Figure2a

plot_FigureS8a

result_Table6
