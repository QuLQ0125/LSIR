disp('Table 6-SCAD')
load('taipei_LSIR_est_SCAD.mat')
Table6_SCAD=results_LSIR.resultTable

disp('Table 6-MCP')
load('taipei_LSIR_est_MCP.mat')
Table6_MCP=results_LSIR.resultTable