This is the Matlab code for Table S3.


The matlab codes:

main_simulation_CaseS2.m: This file is used to calculate the values of EE and PE with different methods and sample sizes n for Case S2.

main_simulation_CaseS3.m: This file is used to calculate the values of EE and PE with different methods and sample sizes n for Case S3.

CaseS2.m: This file is the setting for Case S2.

CaseS3.m: This file is the setting for Case S3.

mygendate.m, gendata.m are used to generate simulated data.

calfun.m: This files is a simplified form of the calculation process, which includes the Matlab code Simulation_SCAD_MCP.m, Simulation_PLSIR.m and Simulation_LR.m.

Simulation_SCAD_MCP.m: This file includes specific calculation steps for SCAD and MCP.

Simulation_PLSIR.m: This file includes specific calculation steps for PLSIR model.

Simulation_LR.m: This file includes specific calculation steps for LR model.

myfilename.m: This file is used to determine the saving path for the calculation results.

result_TableS3.m: This file is used to obtain Table S3.


You can directly carry out the code: main_TableS3.m.
