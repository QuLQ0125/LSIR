vecMn=[10,10,0,0];sigma_star=1;
vecpen={'SCAD','MCP','PLSIR','LR'};c1=1;nu=0.7;
vecn=[125,125,625,625,1250,1250];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
varphi_type='nonlinear-0.25';example=2;
result_TableS3_CaseS2=[];
for i_n=1:2:5
    for j_pen=1:length(vecpen)
        n=vecn(i_n);
        pen=vecpen{j_pen};
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        result_TableS3_CaseS2(i_n,j_pen)=EE;
    end
end


varphi_type='nonlinear-0.25';example=2;
for i_n=2:2:6
    for j_pen=1:length(vecpen)
        n=vecn(i_n);
        pen=vecpen{j_pen};
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        result_TableS3_CaseS2(i_n,j_pen)=PE;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
varphi_type='nonlinear-sin';example=3;
result_TableS3_CaseS3=[];
for i_n=1:2:5
    for j_pen=1:length(vecpen)
        n=vecn(i_n);
        pen=vecpen{j_pen};
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        result_TableS3_CaseS3(i_n,j_pen)=EE;
    end
end


varphi_type='nonlinear-sin';example=3;
for i_n=2:2:6
    for j_pen=1:length(vecpen)
        n=vecn(i_n);
        pen=vecpen{j_pen};
        Mn=vecMn(j_pen);
        load(myfilename(Mn,n,n1,sigma_star,example,pen,c1,nu,varphi_type));
        result_TableS3_CaseS3(i_n,j_pen)=PE;
    end
end


TableS3=[result_TableS3_CaseS2;result_TableS3_CaseS3];


row_labels={'CaseS2-n100-EE','CaseS2-n100-PE','CaseS2-n500-EE','CaseS2-n500-PE','CaseS2-n1000-EE','CaseS2-n1000-PE',...
    'CaseS3-n100-EE','CaseS3-n100-PE','CaseS3-n500-EE','CaseS3-n500-PE','CaseS3-n1000-EE','CaseS3-n1000-PE'};
col_labels={'Ours (SCAD)','Ours (MCP)','PLSIR','LR'};
TableS3_tabletype = array2table(TableS3, ...
    'VariableNames',col_labels,'RowNames', row_labels)
