function Q=qn(T,tau,deltan)
% Q=[];
% for i=1:length(T)
% if T(i)<tau-deltan
%     Q(i,:)=0;
% elseif T(i)>=tau-deltan && T(i)<=tau+deltan
%         Q(i,:)=(T(i)-tau+deltan)^2/(4*deltan);
% elseif T(i)>tau+deltan
%             Q(i,:)=T(i)-tau;
% end
% end
Q=0.*(T<tau-deltan)+(T-tau+deltan).^2/(4*deltan).*(T>=tau-deltan & T<=tau+deltan)+(T-tau).*(T>tau+deltan);
