clc;clear;close all
%%%---taipei_LSIR---%%%
currentFolder = pwd;
parentFolder = fileparts(pwd);
addpath(parentFolder);


redata1=readmatrix('housetaibei.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];%[2,3;2,4;2,5;3,4;3,5;4,5], [2,3,4;2,3,5;3,4,5], [2,3,4,5]

X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
SDXI=ZXI(~ismember(ZXI,SCXI));
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


[n,p]=size(X);
d1=size(X,2);
d2=size(Z,2);





rho=0.8;
c1=1;
Mn=5;
deltan=c1*(log(Mn+1)/n)^(rho);
B=3;
cn=log(log(n));
maxiter=500;
tol=1e-4;

[beta_hat,gamma_hat]=est_PR_global(X,Z,y,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
Beta0wan1=beta_hat;
Gamma0wan1=gamma_hat;
Eta0wan1=[0;Gamma0wan1];
Alpha0wan1=zeros(Mn+1,1);
%plot(X(:,1)+X(:,2:end)*Beta0wan1,y-Z*Gamma0wan1,'.')
Tau0wan1=linspace(min(X(:,1)+X(:,2:end)*Beta0wan1),max(X(:,1)+X(:,2:end)*Beta0wan1),Mn+2)';
Tau0wan1=Tau0wan1(2:end-1);

pen='SCAD';t=3.7;
% pen='MCP';t=3;
Lambdawan=[linspace(0,3,100),10];
% Lambdawan=Lambdawan(end:-1:1);
ifplot='true';
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
results_LSIR=est_LSIR(Z,X,y,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambdawan,t,deltan,cn,pen,maxiter,tol,B,ifplot);




