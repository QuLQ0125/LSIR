clc;clear;close all
%%%---taipei_PLSIR---%%%
example=3;
redata1=readmatrix('housetaibei.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
SDXI=ZXI(~ismember(ZXI,SCXI));
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


numSamples = size(X, 1);
indices =[1:n];
X=X(indices,:);Z=Z(indices,:);y=y(indices,:);

train_rate=1;
X_train=X(1:ceil(train_rate*numSamples),:);
Z_train=Z(1:ceil(train_rate*numSamples),:);
y_train=y(1:ceil(train_rate*numSamples),:);
n_train=size(X_train,1);
X_test=X(ceil(train_rate*numSamples)+1:end,:);
Z_test=Z(ceil(train_rate*numSamples)+1:end,:);
y_test=y(ceil(train_rate*numSamples)+1:end,:);
n_test=size(X_test,1);

vech=[0.3,1,1.5];
cvRMSE=[];cvhatBeta1=[];cvhatGamma1=[];
numSamples_train = size(X_train, 1);
rng(123);
indices_train = randperm(numSamples_train);
X_train=X_train(indices_train,:);Z_train=Z_train(indices_train,:);y_train=y_train(indices_train,:);
cross_k=5;
foldSize = floor(numSamples_train / cross_k);
cvIndices = cell(cross_k, 1);
for i1 = 1:cross_k
    startIdx = (i1 - 1) * foldSize + 1;
    endIdx = i1 * foldSize;
    if i1 == cross_k
        endIdx = numSamples_train;
    end
    cvIndices{i1} = startIdx:endIdx;
end
for k=1:length(vech)
    h=vech(k);
    for r=1:cross_k
        testIdx_r = cvIndices{r};
        trainIdx_r = setdiff(1:numSamples_train, testIdx_r);
        X_train_r = X_train(trainIdx_r, :);
        Z_train_r = Z_train(trainIdx_r, :);
        y_train_r = y_train(trainIdx_r);
        X_test_r = X_train(testIdx_r, :);
        Z_test_r=Z_train(testIdx_r, :);
        y_test_r = y_train(testIdx_r);
        
        [beta_hat,gamma_hat]=est_PR_global(X_train_r,Z_train_r,y_train_r,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
        [hatBeta1_r,hatGamma1_r]=initial_est_SIR_wang(X_train_r,Z_train_r,y_train_r,beta_hat,gamma_hat,h);
        
        Xnew=X_train_r*[1;hatBeta1_r];
        hatYnew=hatf_fun_wang(Xnew,hatBeta1_r,hatGamma1_r,X_train_r,Z_train_r,y_train_r,h);
        RMSE_train_r=sqrt(mean((y_train_r-hatYnew-Z_train_r*hatGamma1_r).^2));
        ESS_train_r=sum((y_train_r-hatYnew-Z_train_r*hatGamma1_r).^2);
        TSS_train_r=sum((y_train_r-mean(y_train_r)).^2);
        R2_train_r=1-ESS_train_r/TSS_train_r;
        
        Xnew=X_test_r*[1;hatBeta1_r];
        x=sort(Xnew);
        hatYnew=hatf_fun_wang(Xnew,hatBeta1_r,hatGamma1_r,X_train_r,Z_train_r,y_train_r,h);
        RMSE_test_r=sqrt(mean((y_test_r-hatYnew-Z_test_r*hatGamma1_r).^2));
        ESS_test_r=sum((y_test_r-hatYnew-Z_test_r*hatGamma1_r).^2);
        TSS_test_r=sum((y_test_r-mean(y_test_r)).^2);
        R2_test_r=1-ESS_test_r/TSS_test_r;
        cvRMSE(r,:,k)=[vech(k),RMSE_train_r,RMSE_test_r,R2_train_r,R2_test_r];
        cvhatBeta1(:,r,k)=hatBeta1_r;
        cvhatGamma1(:,r,k)=hatGamma1_r;
    end
    
    reRMSE_h(k,:)=mean(cvRMSE(:,:,k));
    
end
[~,kopt]=min(reRMSE_h(:,3));%selecting optimal h
h=0.3;%vech(kopt);
tic
[beta_hat,gamma_hat]=est_PR_global(X_train,Z_train,y_train,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
[hatBeta1,hatGamma1]=initial_est_SIR_wang(X_train,Z_train,y_train,beta_hat,gamma_hat,h);
runtime=toc;
Ynew=y_train-Z_train*hatGamma1;
Xnew=X_train*[1;hatBeta1];
x=sort(Xnew);
hatYnew=hatf_fun_wang(Xnew,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
hatynew=hatf_fun_wang(x,hatBeta1,hatGamma1,X_train,Z_train,y_train,h);
RMSE_SIR_train=sqrt(mean((y_train-Z_train*hatGamma1-hatYnew).^2));
ESS_train=sum((y_train-hatYnew-Z_train*hatGamma1).^2);
TSS_train=sum((y_train-mean(y_train)).^2);
R2_train=1-ESS_train/TSS_train;


figure
plot(X_train*[1;hatBeta1],y_train-Z_train*hatGamma1,'.',x,hatynew,'-','Linewidth',2)
xlabel('${X}_i^\top\widehat{\beta}$','interpreter','latex','Fontname','Times New Roman')
ylabel('$Y_i-{Z}_i^\top\mathbf{\widehat\gamma}$','interpreter','latex','Fontname','Times New Roman')

disp('Partially linear single index regression model (PLSIR)')
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
for s3=1:length(hatBeta1)
    beta_cell{s3}=['beta',num2str(s3+1)];
end
for s4=1:length(hatGamma1)
    gamma_cell{s4}=['gamma',num2str(s4)];
end
col_labels=[{'beta1'},beta_cell,gamma_cell,{'PE (test)','R2 (all set)'}];
PEtable=array2table([1,hatBeta1',hatGamma1',reRMSE_h(1,3),R2_train],'VariableNames',col_labels);
disp(PEtable)

