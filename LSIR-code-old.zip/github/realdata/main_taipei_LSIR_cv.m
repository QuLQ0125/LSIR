clc;clear;close all
%%%---taipei_LSIR_cv---%%%
redata1=readmatrix('housetaibei.xlsx');
redata1(:,2)=redata1(:,2)-2012;
c=redata1(:,2);
redata1(:,2)=-redata1(:,4);
redata1(:,4)=c;

redata1(:,2)=(redata1(:,2)-mean(redata1(:,2)))/std(redata1(:,2));
redata1(:,3)=(redata1(:,3)-mean(redata1(:,3)))/std(redata1(:,3));
redata1(:,4)=(redata1(:,4)-mean(redata1(:,4)))/std(redata1(:,4));
redata1(:,5)=(redata1(:,5)-mean(redata1(:,5)))/std(redata1(:,5));
variable_names={'Neg-Meter','Year','Date','Number'};

XIC=[2:5];
ZXI=[2:5];
SCXI=[2,5];
X=redata1(:,SCXI);
[n,p]=size(X);
y=redata1(1:n,end);
SDXI=ZXI(~ismember(ZXI,SCXI));
Z=redata1(1:n,ZXI(~ismember(ZXI,SCXI)));
tildeZ=[ones(n,1),Z];


d1=size(X,2);
d2=size(Z,2);

[beta_hat,gamma_hat]=est_PR_global(X,Z,y,3,zeros(size(X,2)-1,1),zeros(size(Z,2),1));
cvRMSE=[];cvhatBeta11=[];cvhatEta1=[];cvhatTau1=[];

cross_k=5;
numSamples = size(X, 1);
rng(123);
indices = randperm(numSamples);
X=X(indices,:);Z=Z(indices,:);y=y(indices,:);
foldSize = floor(numSamples / cross_k);
cvIndices = cell(cross_k, 1);
for i1 = 1:cross_k
    startIdx = (i1 - 1) * foldSize + 1;
    endIdx = i1 * foldSize;
    if i1 == cross_k
        endIdx = numSamples;
    end
    cvIndices{i1} = startIdx:endIdx;
end
for r=1:cross_k
    testIdx_r = cvIndices{r};
    trainIdx_r = setdiff(1:numSamples, testIdx_r);
    X_train_r = X(trainIdx_r, :);
    Z_train_r = Z(trainIdx_r, :);
    n_train_r=size(X_train_r,1);
    y_train_r = y(trainIdx_r);
    X_test_r = X(testIdx_r, :);
    Z_test_r=Z(testIdx_r, :);
    y_test_r = y(testIdx_r);
    n_test_r=size(X_test_r,1);
    
    
    nu=0.8;
    c1=1;
    Mn=5;
    B=7;
    cn=log(log(n));
    maxiter=1000;
    tol=1e-4;
    deltan=c1*(log(Mn+1)/n_train_r)^(nu);
    
    Beta0wan1=beta_hat;
    Gamma0wan1=gamma_hat;
    Eta0wan1=[0;Gamma0wan1];
    Alpha0wan1=zeros(Mn+1,1);
    Tau0wan1=linspace(min(X_train_r(:,1)+X_train_r(:,2:end)*Beta0wan1),max(X_train_r(:,1)+X_train_r(:,2:end)*Beta0wan1),Mn+2)';%[-1:3]'%
    Tau0wan1=Tau0wan1(2:end-1);
    
    
    pen='SCAD';t=3.7;
%     pen='MCP';t=3;
    lambdamax=3;numlambda=50;
    Lambdawan=[linspace(0.00001,lambdamax*0.7,numlambda*0.9),linspace(lambdamax*0.7,lambdamax,numlambda*0.1),10];
    [ansBIC,hatEta1_r,hatBeta11_r,hatAlpha1_r,hatTau1_r,hatlambda,hatAlpha111_r,hatTau111_r,BICmin]=...
        Global_ADMM(Z_train_r,X_train_r,y_train_r,Mn,Beta0wan1,Eta0wan1,Tau0wan1,Alpha0wan1,Lambdawan,t,deltan,cn,pen,maxiter,tol,B);
    
    Q0_train_r=[];
    T0_train_r=X_train_r*hatBeta11_r;
    Q0_train_r=[T0_train_r,f0(T0_train_r,hatTau1_r')];
    
    ESS_train_r=sum((y_train_r-[ones(n_train_r,1),Z_train_r]*hatEta1_r-Q0_train_r*hatAlpha1_r).^2);
    TSS_train_r=sum((y_train_r-mean(y_train_r)).^2);
    R2_train_r=1-ESS_train_r/TSS_train_r;
    RMSE_train_r=sqrt(mean((y_train_r-[ones(n_train_r,1),Z_train_r]*hatEta1_r-Q0_train_r*hatAlpha1_r).^2));
    
    Q0_test_r=[];
    T0_test_r=X_test_r*hatBeta11_r;
    Q0_test_r=[T0_test_r,f0(T0_test_r,hatTau1_r')];
    
    ESS_test_r=sum((y_test_r-[ones(n_test_r,1),Z_test_r]*hatEta1_r-Q0_test_r*hatAlpha1_r).^2);
    TSS_test_r=sum((y_test_r-mean(y_test_r)).^2);
    R2_test_r=1-ESS_test_r/TSS_test_r;
    RMSE_test_r=sqrt(mean((y_test_r-[ones(n_test_r,1),Z_test_r]*hatEta1_r-Q0_test_r*hatAlpha1_r).^2));
    
    
    
    cvRMSE(r,:)=[RMSE_train_r,R2_train_r,ESS_train_r,TSS_train_r,...
        RMSE_test_r,R2_test_r,ESS_test_r,TSS_test_r,BICmin(2)];
    cvhatAlpha1(:,r)=hatAlpha111_r;
    cvhatTau1(:,r)=hatTau111_r;
    cvhatBeta11(:,r)=hatBeta11_r;
    cvhatEta1(:,r)=hatEta1_r;
    
    
    
end

meanRMSE=mean(cvRMSE);
disp(['Mn=',num2str(Mn),', penalty=',pen])
disp(['group: variables Price as y, ','variables ',strjoin(variable_names(SCXI-1),', '),' as X and ','variables ',strjoin(variable_names(SDXI-1),', '),' as Z'])
PE=meanRMSE(5);
disp(array2table(PE,'VariableNames',...
    {'PE (test)'}))


