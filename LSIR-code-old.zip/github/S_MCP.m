function eta=S_MCP(zeta,lambda,t,vartheta)
if t<=1/vartheta
    fprintf('t>1/vartheta?\n')
end
%     
% if abs(zeta)<=t*lambda
%     fenzi=ST(zeta,lambda/vartheta,t,vartheta);
%     fenmu=1-1/(t*vartheta);
%     eta=fenzi/fenmu;%S_MCP(0.5,0.2,3,1)=0.45,%S_MCP(0.5,0.6,3,1)=0
% elseif abs(zeta)>t*lambda
%     eta=zeta;%S_MCP(3,0.2,3,1)=3
% end
% end

eta=(ST(zeta,lambda/vartheta,t,vartheta))./(1-1/(t*vartheta)).*(abs(zeta)<=t*lambda)+zeta.*(abs(zeta)>t*lambda);

