function Q=f0(T,tau)
% Q=[];
% for i=1:length(T)
%     if T(i)<=tau
%         Q(i,:)=0;
%     elseif T(i)>tau
%         Q(i,:)=T(i)-tau;
%     end
% end
Q=(T-tau).*(T>tau);