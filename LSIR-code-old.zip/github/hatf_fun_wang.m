function hatg=hatf_fun_wang(t,beta,gamma,X,Z,Y,h)
X1=X(:,1);
X2=X(:,2:end);
n=size(X,1);
% K_h=@(x) normpdf(x/h)/h;
K_h1=@(x) normpdf(x/h)/h;
K_h=@(x) K_h1(x).*(K_h1(x)~=0)+realmin.*(K_h1(x)==0);
% K_h=@(x) 0.75*(1-(x/h).^2).*(abs((x/h))<=1)/h+0.00001*(abs((x/h))>1);
Snl=@(L,t,beta) mean((X1+X2*beta-t').^L.*K_h(X1+X2*beta-t'),1)';

%%%---wang---%%%
Wni_fenzi=@(t,beta) K_h(X1+X2*beta-t').*(Snl(2,t,beta)'-(X1+X2*beta-t').*Snl(1,t,beta)');
Wni_fenmu=@(t,beta) Snl(0,t,beta).*Snl(2,t,beta)-Snl(1,t,beta).^2;%0
Wni=@(t,beta) Wni_fenzi(t,beta)./Wni_fenmu(t,beta)';
hatf_fun=@(t,beta,gamma) mean(Wni(t,beta).*(Y-Z*gamma))';

%%%---qu---%%%
% Wni_fenzi=@(t,beta) K_h(X1+X2*beta-t');
% Wni_fenmu=@(t,beta) Snl(0,t,beta);
% Wni=@(t,beta) Wni_fenzi(t,beta)./Wni_fenmu(t,beta)';
% hatf_fun=@(t,beta,gamma) mean(Wni(t,beta).*(Y-Z*gamma))';
hatg=hatf_fun(t,beta,gamma);