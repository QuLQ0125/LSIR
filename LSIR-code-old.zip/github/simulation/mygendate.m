function [n1Z,n1X,n1y,n1Epsilon]=mygendate(meanZ,d2,meanX,d1,sigma_star,n,Gamma_star,Beta_star,Alpha_star,Tau_star,n1,varphi)
n1X=[];
n1Z=[];
n1y=[];
n1Epsilon=[];

for i=1:n1
    [Z,X,y,Epsilon,~]=gendata(meanZ,d2,meanX,d1,sigma_star,n,Gamma_star,Beta_star,Alpha_star,Tau_star,varphi);
    n1X(:,:,i)=X;
    n1Z(:,:,i)=Z;
    n1y(:,i)=y;
    n1Epsilon(:,i)=Epsilon;
end