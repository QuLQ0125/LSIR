function [example,d2,d1,junzZ,junzX,sigmaZ,sigmaX,sigmaxin,...
    Etaxin,Betaxin,Alphaxin,Tauxin,Mnxin,snxin,D,Theta_oxin,varphi,varphi_type]=funex21()
example=21;
d2=1;%beta gamma的维度
d1=2;
junzZ=zeros(1,d2);
junzX=zeros(1,d1);
sigmaZ=eye(d2)*0.5+ones(d2)*0.5;
sigmaX=eye(d1)*0.5+ones(d1)*0.5;
sigmaxin=1;
Etaxin=[0;0.5];
Betaxin=[1;-1];
Alphaxin=[1;-2;2];
Tauxin=[-1;1];
Mnxin=length(Tauxin);
snxin=d1+d2+Mnxin+1+Mnxin;
D=100;
Theta_oxin=[Alphaxin',Tauxin',Betaxin(2:end)',Etaxin'];
varphi=@(w) Etaxin(1)+[w,f0(w,Tauxin')]*Alphaxin;varphi_type='LSIR';
% varphi=@(w) 0.25*w.^2;varphi_type='nonlinear-0.25';
% varphi=@(w) sin(w);varphi_type='nonlinear-sin';
