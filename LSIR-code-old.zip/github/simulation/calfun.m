function calfun(c1,nu,vecMn,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B)


%%%---oracle---%%%

Mn=Mn_star;
deltan=c1*(log(5+1)/n)^(nu);
pen='NULL';
Lambdawan=0;
t=3.7;
Simulation_oracle(Mn,Lambdawan,t,deltan,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type);



% vecMn=Mn;
for i=1:length(vecMn)
%%%---SCAD---%%%
Mn=vecMn(i);
deltan=c1*(log(Mn+1)/n)^(nu);
cn=[1,log(log(n))];

pen='SCAD';
lambdamax=0.2;numlambda=10;
Lambdawan=[linspace(0,lambdamax*0.1,numlambda*0.9),linspace(lambdamax*0.15,lambdamax,numlambda*0.1),3];%
t=3.7;

Simulation_SCAD_MCP(Mn,Lambdawan,t,deltan,cn,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B);


%%%---MCP---%%%
pen='MCP';
lambdamax=0.2;numlambda=10;
Lambdawan=[linspace(0,lambdamax*0.1,numlambda*0.9),linspace(lambdamax*0.15,lambdamax,numlambda*0.1),3];%
t=3;

Simulation_SCAD_MCP(Mn,Lambdawan,t,deltan,cn,pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type,B);
end


%%%---Partially linear single index regression model---%%%
pen='PLSIR';
Simulation_PLSIR(pen,...
    c1,nu,n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type)



%%%---Linear regression model---%%%
pen='LR';
Simulation_LR(pen,...
    n1,n,Eta_star,Beta_star,Tau_star,Theta_o_star,n1Z,n1X,n1y,n1Epsilon,example,Mn_star,...
    d1,d2,meanZ,meanX,sigma_star,sigmaX,sigmaZ,Alpha_star,D,sn_star,varphi,varphi_type)
